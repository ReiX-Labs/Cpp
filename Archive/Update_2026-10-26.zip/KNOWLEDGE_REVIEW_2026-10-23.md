# Kiểm định kiến thức và cấu trúc bài giảng — 23/10/2026

## Kết luận

**Nên hệ thống lại trước khi nhập bài 10–12.** Handoff 01–09 có khung chủ đề phù hợp và các giải thích nền tảng đã kiểm tra phần lớn đúng. Tuy nhiên, website hiện chưa phải một khóa tự học nhất quán: điều hướng, kiến thức tiên quyết, luyện tập và tiến độ dùng các hệ khác nhau; một số khẳng định sai trong tài liệu/bộ thẻ cũ vẫn được hiển thị.

Không cần viết lại toàn bộ. Cần sửa các điểm sai, chọn một lộ trình học chính và phân biệt nó với thư viện tra cứu mở rộng.

## Phạm vi và bằng chứng

- Snapshot: commit `d6790e89fc892b6b3118dde8765362c20db9309b`, trùng `main` trên GitHub khi kiểm tra; workflow Pages của commit này đã thành công, website trả HTTP 200.
- Đọc nội dung thực tế qua `src/content/reference.ts` và `integrateHandoff.ts`, không chỉ đọc markdown gốc. Đối chiếu handoff, quiz, challenge, flashcard, Dashboard, Sidebar và trang ôn tập.
- Kiểm tra sâu phạm vi C++17 bài 01–09; kiểm tra chọn lọc các phần C++ mở rộng đang ảnh hưởng tới lộ trình. Đây không phải chứng nhận đầy đủ mọi đoạn Unreal API hoặc tất cả 56 mục.
- Tra cứu tài liệu Microsoft, C++ Core Guidelines và bản dự thảo chuẩn C++ do cộng đồng WG21 duy trì, hiển thị trên eel.is. Các quy tắc được trích dưới đây áp dụng cho các ví dụ đang xét; không dùng tính năng mới của dự thảo hiện hành để áp đặt lên C++17.
- `npm run check:handoff`: đạt. Kiểm tra này xác minh tích hợp, ID, liên kết, cú pháp bảng; không chứng minh mọi ví dụ C++ đúng.
- Trích nguyên văn ba file Arena của mục 12 handoff và biên dịch bằng MSVC/Visual Studio 2022: `/std:c++17 /permissive- /EHsc /utf-8 /W4 /WX`. Build thành công, chạy ra đúng:

```text
Knight: 80/100 HP
Mage: 70/80 HP
Archer: 40/60 HP
Survivors: 3
```

Đây là kiểm tra ví dụ trong tài liệu, không phải chấm bài 09 của người học. Không chạy những ví dụ có undefined behavior để suy ra đáp án.

## A. Những kiến thức cần sửa

### A1 — Ưu tiên cao: bài đoán output có undefined behavior

`src/data/challenges.ts:105–112`: `Shape` thiếu virtual destructor, nhưng chương trình `delete` một `Circle` qua `Shape*` rồi chấm output cố định `Circle `. Không có bảo đảm output cho toàn bộ chương trình đó. Sửa bằng `virtual ~Shape() = default;`, hoặc giữ đoạn lỗi và đổi câu hỏi thành tìm lỗi. `Cpp_Game_Dev_Reference.md:838–839` cũng cần gọi đúng đây là UB, không chỉ bỏ qua destructor con hoặc rò rỉ. [Chuẩn C++, delete, đoạn 3](https://eel.is/c++draft/expr.delete#3).

### A2 — Ưu tiên cao: ví dụ wrapper sở hữu tài nguyên chưa an toàn khi copy

`FileHandle` (`Cpp_Game_Dev_Reference.md:579–588`) và `Texture` (`:756–761`) có destructor giải phóng tài nguyên nhưng vẫn cho phép copy mặc định. Các ví dụ không tự double-release trong cách dùng đang minh họa; rủi ro xuất hiện khi người học sao chép đối tượng, tạo hai owner cùng giữ một handle/con trỏ. Nên dùng `std::ifstream`/`std::vector` cho ví dụ đầu tiên, hoặc chỉ rõ non-copyable và bổ sung chính sách move khi dạy wrapper. [Core Guidelines C.21](https://isocpp.github.io/CppCoreGuidelines/CppCoreGuidelines#Rc-five).

### A3 — Quy tắc sinh copy/move đang bị diễn đạt quá mức

`Cpp_Game_Dev_Reference.md:765` khẳng định compiler tự sinh cả năm special members. Thực tế có điều kiện sinh và điều kiện deleted; destructor do người dùng khai báo ngăn implicit move constructor. Ví dụ `Inventory` chứa `unique_ptr` ở `:773` cũng không copy được theo mặc định. Cần trình bày Rule of Zero trước, rồi nêu rõ trường hợp class tự quản tài nguyên. [Chuẩn copy/move constructors](https://eel.is/c++draft/class.copy.ctor).

### A4 — Nhầm storage duration với stack/heap

`Cpp_Game_Dev_Reference.md:521` giản lược mọi biến thành hai vùng; `:576` giới hạn RAII vào object trên stack; `:1000` gọi `std::array` là mảng stack. Cần sửa: array chứa số phần tử cố định trong object; vị trí lưu trữ phụ thuộc object đó. RAII dựa vào lifetime của owner, không bắt buộc owner nằm trên stack. [Array overview](https://eel.is/c++draft/array.overview), [Core Guidelines R.1](https://isocpp.github.io/CppCoreGuidelines/CppCoreGuidelines#Rr-raii).

### A5 — Nội dung move không nhất quán với flashcard

`src/data/cards.ts:120` nói nguồn sau move rỗng, trong khi standard-library types thường chỉ bảo đảm trạng thái hợp lệ nhưng không xác định cụ thể nếu không có quy định riêng. Không áp bảo đảm đó tùy tiện lên mọi class tự viết. `Cpp_Game_Dev_Reference.md:659` cũng khẳng định trả vector bằng move, bỏ qua khả năng NRVO. `std::move` chỉ tạo biểu thức cho phép chọn move; bản thân nó không chuyển tài nguyên. [Moved-from library types](https://eel.is/c++draft/lib.types.movedfrom), [copy elision](https://eel.is/c++draft/class.copy.elision).

### A6 — Tra lỗi linker mâu thuẫn với bài 06.5

Phụ lục E (`Cpp_Game_Dev_Reference.md:2760`) gợi ý `#pragma once` để sửa multiple definition ở linker. Handoff đã giải thích đúng giới hạn trong một translation unit. Với hàm non-inline định nghĩa trong header rồi include từ nhiều `.cpp`, cần chuyển definition sang một `.cpp` hoặc dùng `inline` khi thích hợp; thêm include guard không chữa trường hợp đó. [Microsoft LNK2005](https://learn.microsoft.com/en-us/cpp/error-messages/tool-errors/linker-tools-error-lnk2005?view=msvc-170), [pragma once](https://learn.microsoft.com/en-us/cpp/preprocessor/once?view=msvc-170).

### A7 — Các câu tuyệt đối nên chỉnh

- `assert` tại `Cpp_Game_Dev_Reference.md:1149,2050` không phụ thuộc duy nhất tên cấu hình Debug/Release; macro `NDEBUG` quyết định vô hiệu hóa nó. [Microsoft assert](https://learn.microsoft.com/en-us/cpp/c-runtime-library/reference/assert-macro-assert-wassert?view=msvc-170).
- `reserve(1000)` tại `:1297` không bảo đảm vĩnh viễn không realloc; thêm phần tử chỉ được bảo đảm không realloc khi chưa vượt capacity. `reserve` không tăng size. [Vector capacity](https://eel.is/c++draft/vector.capacity).
- “Smart pointer không bao giờ leak” (`:600`) mâu thuẫn với shared ownership cycle được giải thích ngay sau đó (`:633`). Cần bỏ khẳng định tuyệt đối.
- `emplace_back` tại `:1014` và checklist `:2119` không nên được dạy như lựa chọn luôn nhanh hơn `push_back`; cần phân biệt xây phần tử từ đối số với đưa một object đã có vào container.

## B. Cấu trúc hiện tại gây khó tiếp thu ở đâu?

| Vấn đề đã xác minh | Bằng chứng | Hệ quả |
|---|---|---|
| Hai hệ số bài | `handoff.ts:13–23` và `Dashboard.tsx:29–37` | Bài 09 handoff là pointer, mục 9 thư viện là RAII; nút Tiếp tục đi theo 56 mục cũ |
| Dùng kiến thức trước khi dạy | `integrateHandoff.ts:74–90` | Mục 5 dùng Player/reference, mục 6 dùng Arena có array/struct; struct ở mục 12, container ở 20 |
| Chuỗi cơ bản ở quá xa | `integrateHandoff.ts:95` | std::string của bài 07 nằm ở mục 49, phía sau nhiều nội dung nâng cao/Unreal |
| Ôn cả kiến thức chưa học | `Review.tsx:22–29` | Lấy 40 thẻ chưa có trạng thái/đến hạn từ toàn bộ 74 thẻ; không lọc bài đã học |
| Lộ trình handoff chưa có tiến độ riêng | `Fundamentals.tsx:7–18,40–55` | Đọc 01–09 không phản ánh tương ứng vào chỉ số 56 bài của Dashboard |
| Luyện tập lệch bài | `quizzes.ts:470–477,536–547` | Mục 3 hỏi narrowing chưa giảng trong body đó; mục 49 chỉ hỏi chuỗi Unreal, không kiểm tra std::string mới |
| Lặp nội dung | `integrateHandoff.ts:65,90,93,95` | const/constexpr ở 3 và 22; nối/tìm/cắt chuỗi xuất hiện trong cả ví dụ Mario lẫn Knight |

Việc giữ số mục cũ khi ghép handoff đã làm nội dung xuất hiện đúng chủ đề nhưng chưa giải quyết thứ tự học. Đây là hạn chế của lần tích hợp trước, không phải lỗi của bản handoff.

Số lượng luyện tập hiện tại ở các mục liên quan:

| Mục | Quiz | Code / đoán output | Flashcard |
|---|---:|---:|---:|
| 3 — Biến/toán tử | 1 | 0 | 1 |
| 4 — Điều kiện/vòng lặp | 0 | 0 | 1 |
| 5 — Hàm | 1 | 1 | 1 |
| 6 — Pointer | 3 | 1 | 2 |
| 20 — Containers | 2 | 1 | 2 |
| 49 — String | 2 | 0 | 1 |

23 câu tự kiểm tra handoff hữu ích nhưng nằm riêng; không bù được sự lệch giữa từng bài và tab Luyện tập.

## C. Đủ và thiếu trong phạm vi hiện tại

**Đã có khung ôn 01–09:** biến/kiểu, const/constexpr/auto/cast, toán tử, điều kiện, vòng lặp, hàm, header/source, array/vector/string, struct/enum/reference, pointer. Phần tự kiểm tra về chia nguyên, short-circuit, reference không rebind và nullptr có giải thích phù hợp.

**Nên bổ sung ngay trong nền tảng:**

1. Một ví dụ nhập tên và HP chạy độc lập, có nhập sai và EOF; xử lý newline khi chuyển từ `>>` sang `getline`. Hiện handoff chỉ nhắc vấn đề ở dòng 170–171 và 629. [Microsoft getline](https://learn.microsoft.com/en-us/cpp/standard-library/string-functions?view=msvc-170).
2. Khởi tạo bằng `{}` và narrowing trước khi ra quiz về chúng; phân biệt đoạn minh họa với chương trình có thể chép chạy nguyên vẹn.
3. Cầu nối container → pointer: size/capacity, reserve/resize, invalidation. Đặc biệt, realloc của vector làm pointer/reference/iterator tới phần tử cũ mất hiệu lực. [Vector modifiers](https://eel.is/c++draft/vector.modifiers).
4. Bài kiểm tra biên nhỏ: null, container rỗng, HP=0/maxHP, amount=0/âm; giải thích các giả định đầu vào của ví dụ.
5. Đưa breakpoint, đọc warning và cách phân biệt compile/link/runtime vào bài thực hành đầu tiên, thay vì chủ yếu xuất hiện ở mục 43.

**Chưa có trong handoff vì đang chờ bài mới:** vòng đời/cấp phát động, class/constructor/destructor, this/kế thừa. Không coi phần này là đã học chỉ vì thư viện cũ có bài tương ứng. Không cần nhồi templates nâng cao, multithreading hoặc toàn bộ Unreal vào giai đoạn 01–09.

“Đủ” ở đây phải gắn với đầu ra: tự viết được mini-project, giải thích được từng lựa chọn kiểu/tham số và vượt bài kiểm tra biên; số lượng thuật ngữ không chứng minh mức thành thạo.

## D. Đề xuất hệ thống lại

Đây là đề xuất dựa trên quan hệ kiến thức tiên quyết và trạng thái người học, không phải một thứ tự bắt buộc do chuẩn C++ quy định.

### Một luồng học chính

| Bài | Mục tiêu |
|---|---|
| 01 | Môi trường, chương trình đầu tiên, nhập/xuất, đọc lỗi |
| 02 | Biến/kiểu, khởi tạo, const/constexpr, auto, cast |
| 03 | Toán tử; bitmask là phần vận dụng thêm |
| 04 | Điều kiện và scope |
| 05 | Vòng lặp, break/continue |
| 06 | Hàm, tham số theo giá trị, return, prototype, overload |
| 06.5 | Tách header/source và compiler/linker |
| 07 | Array, vector, string; truy cập an toàn |
| 08 | Struct, enum class, reference và const reference |
| 09 | Pointer, nullptr, lifetime cơ bản; liên hệ container invalidation |
| Sau 09 | Arena tích hợp ba file, tự kiểm tra và bài thực hành tổng hợp |
| 10–12 | Mở theo tài liệu mới; không tự xác nhận trạng thái học |

Mỗi bài dùng cùng cấu trúc: **mục tiêu → cần biết trước → giải thích → ví dụ chạy được → lỗi thường gặp → luyện tập → tiêu chí hoàn thành**. Mỗi bài nên có câu hỏi hiểu ý nghĩa, đoán output và một bài viết code ngắn, thay vì chỉ đánh dấu đã đọc.

### Thư viện và ôn tập

- Đổi vai trò 56 mục hiện tại thành **Thư viện kiến thức**, có nhãn nền tảng / mở rộng / Unreal và phiên bản C++ tối thiểu. Giữ truy cập tự do.
- Cho Dashboard, nút Tiếp tục, bài trước/sau và tiến độ khóa học dùng lộ trình 01–12. Nội dung lý thuyết phải xuất hiện trực tiếp ở bài, không chỉ thêm ghi chú trỏ sang nơi khác.
- Phần trùng dùng một nguồn chủ đề chuẩn; thư viện có thể nhắc lại ngắn và liên kết, không nhân bản những bài dài như hai khóa độc lập.
- Ôn hằng ngày mặc định lấy thẻ của bài đã được người học xác nhận học; tùy chọn ôn mở rộng phải chủ động. Giữ lịch SRS hiện có.
- Giữ `/lesson/:id`, ID câu hỏi/thẻ và localStorage cũ. Thêm ánh xạ khóa học/tiến độ khóa học riêng; không đổi số hàng loạt hoặc suy hoàn thành hai bài từ một mục tổng hợp đã đọc.

## E. Thứ tự thực hiện và tiêu chí nghiệm thu

1. Sửa A1–A6 trong bài, quiz, thẻ và tra cứu cùng lúc; ưu tiên lỗi dẫn tới hiểu sai tính an toàn của code.
2. Chọn lộ trình chính và sửa điều hướng/tiến độ; kiểm thử giữ dữ liệu học đã có.
3. Bổ sung ví dụ chạy được và bài tập cho các phần C; ghép 23 câu hỏi vào đúng bài.
4. Khi có handoff 10–12, nhập theo khóa chủ đề ổn định; kiểm tra số chương/tiêu đề thay đổi, không chỉ nối thêm markdown.
5. CI cần kiểm tra tích hợp, đáp án, liên kết; các ví dụ được gắn nhãn chạy độc lập phải compile theo chuẩn công bố. Build React thành công chưa đủ.

Lượt này tạo báo cáo kiểm định; các lỗi được nêu chưa được sửa trên website. Báo cáo không thay đổi trạng thái đã học/chấm bài của người học.
