# GIÁO TRÌNH ÔN TẬP C++ — TỪ CƠ BẢN ĐẾN TEMPLATES

**Phiên bản:** 1.0 — 24/10/2026  
**Môi trường thực hành:** Visual Studio 2022, Console App (C++), ưu tiên C++17 trở lên  
**Phạm vi:** Những kiến thức đã học và thực hành trong **Bài 01–13**, bao gồm Bài 06.5, Bài 12.1 và 12.2  
**Định hướng:** Nắm vững Standard C++ để chuẩn bị học Unreal Engine C++ ở một khóa riêng.

> **Cách dùng:** Đây là tài liệu độc lập để cập nhật giáo trình hoặc gửi cho trợ giảng/AI khác. Mỗi phần có **bản chất → cú pháp → ví dụ → lưu ý**. Nội dung chưa được dạy đầy đủ được đánh dấu **Chưa học sâu** để tránh nhầm kiến thức đã thành thạo với kiến thức mới chỉ được giới thiệu.

---

## MỤC LỤC

1. [Thiết lập & cách chương trình C++ hoạt động](#00-thiết-lập--cách-chương-trình-c-hoạt-động)
2. [Bài 01 — Cấu trúc chương trình, nhập/xuất](#01-cấu-trúc-chương-trình-nhậpxuất)
3. [Bài 02 — Biến, kiểu dữ liệu, const, constexpr, auto, cast cơ bản](#02-biến-kiểu-dữ-liệu-const-constexpr-auto-cast-cơ-bản)
4. [Bài 03 — Toán tử](#03-toán-tử)
5. [Bài 04 — Điều kiện](#04-cấu-trúc-điều-kiện)
6. [Bài 05 — Vòng lặp](#05-vòng-lặp)
7. [Bài 06 — Hàm](#06-hàm-functions)
8. [Bài 06.5 — Header, Source, Compiler, Linker](#065-header-source-compiler-linker)
9. [Bài 07 — Array, Vector, String](#07-mảng-vector-và-string)
10. [Bài 08 — Struct, Enum, Reference](#08-struct-enum-class-reference)
11. [Bài 09 — Pointer](#09-pointer-con-trỏ)
12. [Bài 10 — Memory, RAII, Smart Pointer](#10-stack-heap-dynamic-memory-smart-pointer)
13. [Bài 11 — Class, OOP, Constructor](#11-class-encapsulation-constructor)
14. [Bài 12 — Kế thừa, đa hình, virtual, this, destructor](#12-kế-thừa-đa-hình-this-destructor)
15. [Bài 13 — Templates](#13-templates-fundamentals)
16. [Bảng tra cứu cú pháp](#14-bảng-tra-cứu-nhanh-các-cú-pháp)
17. [Lỗi hay gặp & tư duy viết code](#15-lỗi-hay-gặp-và-tư-duy-viết-code)
18. [Tổng hợp bài tập đã thực hành](#16-những-bài-tập-đã-thực-hành)
19. [Kiến thức chưa học & kế hoạch tiếp theo](#17-những-nội-dung-chưa-học-và-lộ-trình-tiếp)

---

## 00. THIẾT LẬP & CÁCH CHƯƠNG TRÌNH C++ HOẠT ĐỘNG

### 00.1. Công cụ

- **Visual Studio 2022:** IDE để viết, build, chạy, debug.
- **MSVC:** Compiler C++ thường dùng khi build từ Visual Studio trên Windows.
- **Project / Solution:** Cấu trúc Visual Studio quản lý source, setting, build configurations.
- **Console App (C++):** Loại project thực hành đã sử dụng.

Lệnh phím phổ biến trong Visual Studio:

| Phím | Ý nghĩa |
|---|---|
| `Ctrl + F5` | Chạy chương trình không gắn debugger |
| `F5` | Chạy với debugger |
| `Ctrl + Shift + B` | Build Solution |
| `F9` | Đặt/bỏ breakpoint ở dòng hiện tại |
| `F10` | Step Over (thực thi dòng, không vào trong hàm được gọi) |
| `F11` | Step Into (bước vào hàm) |
| `Shift + F11` | Step Out (thoát khỏi hàm hiện tại trong debugger) |
| `Ctrl + Alt + L` | Mở Solution Explorer |

> Phần debugger nâng cao sẽ được học có hệ thống ở Bài 17. Các phím trên là để tra cứu trước.

### 00.2. Pipeline build

```text
File .h + file .cpp
       |
       v
Preprocessor (#include, #define, ...)
       |
       v
Compiler -> object file (.obj)
       |
       v
Linker (kết nối các object file / library)
       |
       v
Executable (.exe)
```

- **Compiler error:** Lỗi cú pháp, kiểu dữ liệu, thiếu khai báo, phạm vi truy cập…
- **Linker error:** Có lời gọi/khai báo nhưng không tìm thấy định nghĩa, hoặc định nghĩa trùng…
- **Runtime/logic error:** Build thành công nhưng chạy sai, crash hoặc cho kết quả không mong muốn.

**CMake** (đã hỏi thêm trước đây): Công cụ cấu hình/tạo hệ thống build. **CMake không phải ngôn ngữ C++ và không phải compiler.** Không bắt buộc cho Unreal gameplay: Unreal có UnrealBuildTool riêng. Đây là khái niệm công cụ, không tính thành một bài ngôn ngữ trong 01–13.

---

## 01. CẤU TRÚC CHƯƠNG TRÌNH, NHẬP/XUẤT

### 01.1. Chương trình C++ tối thiểu

```cpp
#include <iostream>

int main()
{
    std::cout << "Hello, World!\n";
    return 0;
}
```

| Cú pháp | Công dụng |
|---|---|
| `#include <iostream>` | Đưa khai báo từ thư viện nhập/xuất vào translation unit |
| `int main()` | Entry point của chương trình console C++ |
| `{ ... }` | Khối lệnh / xác lập scope |
| `std::cout` | Luồng xuất chuẩn (console) |
| `<<` | Toán tử đưa dữ liệu vào luồng xuất |
| `"text"` | Chuỗi ký tự (string literal) |
| `\n` | Xuống dòng |
| `;` | Kết thúc câu lệnh (khi cú pháp yêu cầu) |
| `return 0;` | Kết thúc `main` thành công; ở cuối `main`, bỏ dòng này vẫn ngầm trả về 0 |
| `// ...` | Comment một dòng |
| `/* ... */` | Comment nhiều dòng |

### 01.2. Nhập xuất dữ liệu

```cpp
#include <iostream>
#include <string>

int main()
{
    std::string name;
    int health = 0;

    std::cout << "Name: ";
    std::cin >> name;       // Đọc một từ, dừng ở khoảng trắng

    std::cout << "HP: ";
    std::cin >> health;

    std::cout << "Player: " << name << ", HP=" << health << '\n';
}
```

- `std::cin >> variable;` đọc dữ liệu vào biến.
- `std::cout << value;` in dữ liệu ra màn hình.
- `std::boolalpha` khiến bool in thành `true`/`false` thay vì `1`/`0`, và trạng thái định dạng được giữ trên luồng cho các lần in sau.
- `std::getline(std::cin, name)` đọc cả dòng, kể cả dấu cách; khi dùng ngay sau `std::cin >> number`, cần chú ý ký tự xuống dòng còn trong bộ đệm nhập.
- Nếu người dùng nhập chữ vào biến `int`, đọc từ `std::cin` có thể thất bại. Không tiếp tục sử dụng giá trị chưa khởi tạo; kiểm tra tình trạng đọc dữ liệu nếu xây dựng ứng dụng thực tế.

```cpp
int health = 0;
if (!(std::cin >> health))
{
    std::cout << "Invalid input!\n";
    return 1;
}
```

### 01.3. Các dấu thường nhầm

- `'A'`: literal ký tự (char), khác `"A"`: chuỗi ký tự.
- C++ phân biệt chữ hoa và thường: `main` khác `Main`.
- `=` là gán; `==` là so sánh (xem Bài 03).

---

## 02. BIẾN, KIỂU DỮ LIỆU, CONST, CONSTEXPR, AUTO, CAST CƠ BẢN

### 02.1. Kiểu dữ liệu

| Kiểu / Cú pháp | Ý nghĩa | Ví dụ |
|---|---|---|
| `int` | Số nguyên có dấu | `int hp = 100;` |
| `unsigned int` | Số nguyên không dấu | `unsigned int mask = 0u;` |
| `float` | Số thực đơn chính xác | `float speed = 5.5f;` |
| `double` | Số thực độ chính xác cao hơn float | `double ratio = 0.95;` |
| `bool` | Logic đúng/sai | `bool alive = true;` |
| `char` | Ký tự kiểu char | `char rank = 'A';` |
| `std::string` | Chuỗi ký tự | `std::string name = "Mage";` |
| `std::size_t` | Kiểu không dấu dùng cho kích thước/chỉ số | `std::size_t count = 0;` |

Không mặc định mọi nền tảng có cùng kích thước `int`, `long`… Khi cần độ rộng chính xác, sau này có thể sử dụng `<cstdint>` (`std::int32_t`, …). Trong Unreal có `int32`.

### 02.2. Khai báo và khởi tạo

```cpp
int health = 100;      // Khởi tạo bằng dấu =
int coins(20);         // Direct initialization
int maxHP{200};        // Brace initialization
float speed{5.5f};
```

Khởi tạo bằng `{}` có khả năng phát hiện một số phép chuyển đổi làm mất dữ liệu (**narrowing**):

```cpp
// int x{3.5};  // Lỗi vì chuyển double sang int bị narrowing
int x = 3.5;    // Hợp lệ về cú pháp, x thành 3; cần tránh nếu không cố ý
```

Nên khởi tạo biến ngay khi khai báo, trừ khi có lý do cụ thể.

### 02.3. `const` và `constexpr`

```cpp
const int initialHP = 100;       // Không sửa được qua tên biến
constexpr int maxHP = 200;      // Phải có giá trị khởi tạo dùng được ở compile-time

int input = 0;
std::cin >> input;
const int runtimeConstant = input;  // Hợp lệ
// constexpr int broken = input;    // Không hợp lệ
```

- `const` bảo vệ khỏi việc sửa biến qua cách truy cập đó. `const` **không đồng nghĩa** giá trị luôn được tính tại runtime; ví dụ `const int n = 3` vẫn có thể dùng trong nhiều ngữ cảnh yêu cầu constant expression.
- `constexpr` yêu cầu giá trị/thành phần liên quan có thể được đánh giá tại thời điểm biên dịch theo quy tắc của C++.
- Không chọn `constexpr` vì tin rằng nó **luôn nhanh hơn** `const`; lợi ích chính là tính đúng đắn và khả năng dùng trong constant expressions.

### 02.4. `auto` — suy luận kiểu

```cpp
auto health = 100;       // int
auto speed = 5.5f;       // float
auto ratio = 0.95;       // double
auto isAlive = true;     // bool
```

`auto` được compiler suy luận **lúc biên dịch**, không phải kiểu dữ liệu động tự biến đổi khi chạy. Với các trường hợp phức tạp, `auto` có quy tắc suy luận và bỏ `const`/reference nhất định; sẽ học kỹ hơn khi cần.

### 02.5. Ép kiểu (Casting) ở mức đã học

```cpp
int health = 75;
int maxHP = 200;
float ratio = static_cast<float>(health) / maxHP; // 0.375
```

Vì sao cần cast? `75 / 200` là **chia nguyên** và cho ra `0` trước khi được gán vào float. `static_cast<float>(health)` làm một toán hạng thành `float`, khiến phép chia dùng số thực.

```cpp
int hp = static_cast<int>(75.9f); // 75 (bỏ phần thập phân)
```

**Đã học:** ép kiểu ngầm định cơ bản và `static_cast` trong phép số học.  
**Chưa học đầy đủ:** `dynamic_cast`, `const_cast`, `reinterpret_cast`, quy tắc chuyển kiểu giữa lớp cha/con. Nội dung này dự kiến ở **Bài 14.5 — Casting**; không tự xem là đã thành thạo.

---

## 03. TOÁN TỬ

### 03.1. Số học và gán

| Cú pháp | Ý nghĩa | Ví dụ |
|---|---|---|
| `+` | Cộng | `5 + 2` → 7 |
| `-` | Trừ | `5 - 2` → 3 |
| `*` | Nhân | `5 * 2` → 10 |
| `/` | Chia | `5 / 2` → 2 với hai số nguyên |
| `%` | Chia lấy dư số nguyên | `5 % 2` → 1 |
| `=` | Gán | `hp = 100;` |
| `+=` | Cộng và gán | `hp += 10;` |
| `-=` | Trừ và gán | `hp -= 20;` |
| `*=` | Nhân và gán | `x *= 2;` |
| `/=` | Chia và gán | `x /= 2;` |
| `%=` | Lấy dư và gán | `x %= 2;` |

`%` là toán tử số nguyên; với số thực, dùng chức năng phù hợp trong thư viện toán nếu cần. Không chia số nguyên cho 0.

### 03.2. So sánh và logic

| Cú pháp | Ý nghĩa |
|---|---|
| `==` | Bằng nhau |
| `!=` | Khác nhau |
| `>` / `<` | Lớn hơn / nhỏ hơn |
| `>=` / `<=` | Lớn hơn hoặc bằng / nhỏ hơn hoặc bằng |
| `&&` | Logic AND; short-circuit nếu vế trái sai |
| `||` | Logic OR; short-circuit nếu vế trái đúng |
| `!` | Logic NOT |

```cpp
bool isAlive = health > 0;
bool canFight = isAlive && stamina >= 20;
```

Short-circuit quan trọng khi kiểm tra con trỏ:

```cpp
if (player != nullptr && player->health > 0)
{
    // Chỉ dereference khi con trỏ khác nullptr.
}
```

Lưu ý: Với `float`, so sánh `==` sau nhiều phép tính số thực có thể không đúng kỳ vọng vì sai số biểu diễn.

### 03.3. Tăng/giảm và toán tử ba ngôi

| Cú pháp | Ý nghĩa |
|---|---|
| `++x` | Tăng x trước, biểu thức nhận giá trị mới |
| `x++` | Biểu thức nhận giá trị cũ, sau đó x tăng |
| `--x` / `x--` | Tương tự, giảm 1 |
| `condition ? a : b` | Chọn biểu thức a hoặc b tùy điều kiện |

```cpp
int x = 5;
int y = x++; // y = 5, x = 6
int z = ++x; // x = 7, z = 7

const char* label = (x > 0) ? "Positive" : "Non-positive";
```

Đừng viết biểu thức kết hợp nhiều thao tác tăng/giảm trên cùng biến kiểu `x++ + ++x`; có thể dẫn đến hành vi không xác định.

### 03.4. Bitwise

| Cú pháp | Ý nghĩa |
|---|---|
| `a & b` | Bitwise AND |
| `a \| b` | Bitwise OR |
| `a ^ b` | Bitwise XOR (không phải lũy thừa) |
| `~a` | Đảo từng bit |
| `a << n` | Dịch trái n bit |
| `a >> n` | Dịch phải n bit |
| `&=`, `\|=`, `^=`, `<<=`, `>>=` | Biến thể gán kết hợp |

```cpp
unsigned int a = 5u; // 0101
unsigned int b = 3u; // 0011

a & b; // 0001 => 1
a | b; // 0111 => 7
a ^ b; // 0110 => 6
```

Ứng dụng tiêu biểu: **bit flags/bitmasks**.

```cpp
constexpr unsigned int CanJump  = 1u << 0;
constexpr unsigned int CanShoot = 1u << 1;

unsigned int abilities = 0u;
abilities |= CanJump;                      // Bật cờ
abilities |= CanShoot;
abilities &= ~CanShoot;                   // Tắt cờ
abilities ^= CanJump;                     // Đảo cờ
bool canJump = (abilities & CanJump) != 0; // Kiểm tra
```

Trong bài tập game thông thường, **không thay `* 2` bằng `<< 1` một cách máy móc**: compiler hiện đại tối ưu tốt; biểu thức số học rõ nghĩa và an toàn hơn. Khi thao tác bit, ưu tiên kiểu unsigned; không sử dụng dịch bit với số âm hay số lượng bit dịch không hợp lệ.

### 03.5. Ưu tiên toán tử

Thứ tự phổ biến (từ cao xuống thấp): dấu ngoặc → toán tử một ngôi → `* / %` → `+ -` → dịch bit → so sánh → bằng/khác → bitwise `&`, `^`, `|` → `&&`, `||` → gán. Dùng dấu ngoặc để làm ý định rõ ràng hơn.

---

## 04. CẤU TRÚC ĐIỀU KIỆN

### 04.1. `if` / `else if` / `else`

```cpp
if (health <= 0)
{
    std::cout << "Dead\n";
}
else if (health <= 30)
{
    std::cout << "Critical\n";
}
else
{
    std::cout << "Alive\n";
}
```

- Chỉ nhánh **đúng đầu tiên** trong chuỗi if/else-if/else chạy.
- Hai khối `if` độc lập **có thể cùng chạy** nếu cả hai điều kiện đều đúng.
- Có thể lồng if hoặc dùng `&&` để kết hợp điều kiện; đừng lồng quá sâu nếu không cần.

### 04.2. `switch` / `case` / `break` / `default`

```cpp
switch (potionType)
{
    case 1:
        health += 25;
        break;
    case 2:
        health += 60;
        break;
    default:
        break;
}
```

- `switch` kiểm tra biểu thức kiểu số nguyên hoặc enum phù hợp; không trực tiếp dùng `std::string`.
- `case`: Nhánh ứng với giá trị cụ thể.
- `break`: Thoát `switch`; nếu thiếu có thể chạy tiếp các nhánh phía sau (**fallthrough**).
- `default`: Trường hợp không khớp case nào; có thể bỏ khi không cần.
- `[[fallthrough]];` (C++17) để biểu thị có chủ ý chạy tiếp sang case sau; chỉ cần biết, chưa dùng sâu.

### 04.3. Scope

```cpp
int health = 100;
if (health > 0)
{
    int damage = 20;
    health -= damage;
}
// damage không còn nằm trong scope này.
```

---

## 05. VÒNG LẶP

### 05.1. `for`

```cpp
for (int i = 1; i <= 5; ++i)
{
    std::cout << "Round " << i << '\n';
}
```

Cú pháp: `for (khởi_tạo; điều_kiện; cập_nhật) { ... }`. Hữu ích khi có biến đếm/số lượt rõ ràng.

### 05.2. `while`

```cpp
while (health < 100)
{
    health += 10;
}
```

Kiểm tra điều kiện **trước** mỗi lượt. Nếu điều kiện sai ngay từ đầu, không chạy lần nào.

### 05.3. `do ... while`

```cpp
int choice = 0;
do
{
    std::cout << "1. Play / 0. Quit: ";
    std::cin >> choice;
} while (choice != 0);
```

Chạy **ít nhất một lần**, rồi mới kiểm tra. Có dấu `;` sau `while (...)`.

### 05.4. `break`, `continue`

```cpp
for (int round = 1; round <= 5; ++round)
{
    if (damage < 0) continue; // Bỏ phần còn lại của lượt này
    if (health == 0) break;   // Kết thúc vòng lặp
}
```

- `break` thoát vòng lặp (hoặc switch) gần nhất.
- `continue` bỏ phần còn lại của **lượt lặp hiện tại**, chuyển sang bước cập nhật/kiểm tra vòng lặp tiếp theo.
- Chú ý vòng lặp vô hạn do không cập nhật biến điều kiện.

### 05.5. Range-based for

```cpp
for (int hp : healthValues)             // Sao chép mỗi int
    std::cout << hp;

for (Player& p : players)                // Tham chiếu: sửa được đối tượng
    p.TakeDamage(10);

for (const Player& p : players)          // Chỉ đọc: không sao chép Player
    PrintPlayer(p);
```

- `auto&` / `const auto&` có thể dùng để tránh phải gõ tên kiểu trong range-based for.
- Không có quy tắc rằng range-based for mặc nhiên tốn RAM hơn indexed for; chi phí phụ thuộc kiểu phần tử và việc copy/reference.

---

## 06. HÀM (FUNCTIONS)

### 06.1. Khai báo, định nghĩa, gọi

```cpp
int Add(int a, int b);  // Declaration / Prototype

int main()
{
    int result = Add(3, 5); // Call
    return result;
}

int Add(int a, int b)  // Definition
{
    return a + b;
}
```

| Cú pháp | Ý nghĩa |
|---|---|
| `int Add(int a, int b);` | Khai báo hàm, chỉ tên, kiểu tham số, kiểu trả về |
| `int Add(...) { ... }` | Định nghĩa phần xử lý của hàm |
| `Add(3, 5)` | Gọi hàm với hai đối số |
| `return expression;` | Trả giá trị và kết thúc lời gọi |
| `void Print()` | Hàm không trả giá trị |
| `return;` trong hàm void | Kết thúc sớm, không trả giá trị |

### 06.2. Pass by value và pass by reference

```cpp
void DamageCopy(int hp)  { hp -= 20; } // Không sửa biến gốc
void DamageRef(int& hp)  { hp -= 20; } // Sửa biến gốc

int hp = 100;
DamageCopy(hp); // hp vẫn 100
DamageRef(hp);  // hp còn 80
```

- `T value`: Sao chép (đối với kiểu giá trị như int và các đối tượng có khả năng copy).
- `T& ref`: Tham chiếu, có thể thay đổi đối tượng gốc.
- `const T& ref`: Tham chiếu chỉ đọc qua ref, thường tránh sao chép đối tượng lớn.
- `T* ptr`: Nhận con trỏ, cần kiểm tra hiệu lực và có thể chấp nhận `nullptr` nếu thiết kế cho phép.

### 06.3. Function overloading

```cpp
int Add(int a, int b)       { return a + b; }
float Add(float a, float b) { return a + b; }
```

Overload phân biệt bởi danh sách tham số thích hợp. **Chỉ thay kiểu trả về không đủ để overload.**

### 06.4. Tách trách nhiệm

Một hàm xử lý damage nên chủ yếu tính/tác động trạng thái, hàm hiển thị nên phụ trách in dữ liệu. Đặt tên thể hiện mục đích: `ApplyDamage`, `IsAlive`, `PrintResult`. Đây là bài học quan trọng từ các mini-project.

---

## 06.5. HEADER, SOURCE, COMPILER, LINKER

### 06.5.1. Cấu trúc nhiều file

```text
TrainingArena/
  Arena.h
  Arena.cpp
  Main.cpp
```

`Arena.h`:

```cpp
#pragma once

int ApplyDamage(int health, int damage);
bool IsAlive(int health);
```

`Arena.cpp`:

```cpp
#include "Arena.h"

int ApplyDamage(int health, int damage)
{
    if (damage <= 0) return health;
    if (damage >= health) return 0;
    return health - damage;
}

bool IsAlive(int health)
{
    return health > 0;
}
```

`Main.cpp`:

```cpp
#include <iostream>
#include "Arena.h"

int main()
{
    int hp = ApplyDamage(100, 30);
    std::cout << std::boolalpha << IsAlive(hp) << '\n';
}
```

- `#pragma once`: Tránh cùng một header bị include nhiều lần trong **một translation unit**.
- `#include <iostream>`: Include thư viện chuẩn; `#include "Arena.h"`: Include file dự án.
- **Mỗi `.cpp` được biên dịch riêng.** `Main.cpp` đã include `<iostream>` không có nghĩa `Arena.cpp` tự nhìn thấy khai báo của nó.
- Không `#include` `.cpp` để thay cho hệ thống build đúng cách.
- Tên `Arena.h` trong `#include` phải khớp tên file và cấu hình đường tìm kiếm; hậu tố tải file như `Arena(1).h` chỉ là tên bản sao bên ngoài project.

### 06.5.2. Lỗi build phổ biến

| Lỗi / Tình huống | Nguyên nhân thường gặp |
|---|---|
| Hàm “identifier not found” / C3861 | Thiếu khai báo, include hoặc scope |
| LNK2019 unresolved external symbol | Đã gọi/khai báo nhưng linker không tìm được phần định nghĩa được build |
| LNK2005 symbol already defined | Định nghĩa trùng, ví dụ định nghĩa hàm thường trong header được include ở nhiều TU |
| Include file not found | Sai tên file, đường dẫn hoặc project include directories |

Định nghĩa function template trong header là trường hợp đặc biệt phổ biến và hợp lệ (Bài 13). Với hàm thông thường định nghĩa trong header, cần hiểu `inline`/ODR; chưa học sâu.

---

## 07. MẢNG, VECTOR VÀ STRING

### 07.1. C-style array

```cpp
int health[3] = {100, 80, 60};
std::cout << health[0]; // 100
```

Index bắt đầu từ 0; truy cập ngoài vùng mảng là hành vi không xác định.

### 07.2. `std::array<T, N>` — kích thước cố định

```cpp
#include <array>
std::array<int, 3> hp = {100, 80, 60};
std::cout << hp.size();   // 3
std::cout << hp[1];      // 80
std::cout << hp.at(1);   // 80, kiểm tra phạm vi
```

`std::array` có kích thước cố định trong kiểu của nó. `std::array<int, 3>` và `std::array<int, 4>` là hai kiểu khác nhau.

### 07.3. `std::vector<T>` — thay đổi kích thước

```cpp
#include <vector>
std::vector<int> inventory{10, 20};
inventory.push_back(30);
inventory.pop_back();
std::cout << inventory.size();
```

| Phương thức | Ý nghĩa |
|---|---|
| `.push_back(v)` | Thêm một phần tử cuối vector |
| `.pop_back()` | Xóa phần tử cuối (đảm bảo vector không rỗng) |
| `.size()` | Số phần tử hiện tại |
| `.empty()` | Có rỗng không |
| `.clear()` | Xóa tất cả phần tử |
| `.at(i)` | Truy cập có kiểm tra index, có thể ném exception |
| `[i]` | Truy cập không kiểm tra biên (nếu i sai: hành vi không xác định) |

### 07.4. `std::string`

```cpp
#include <string>
std::string name = "Mario";
name += " Bros";
std::cout << name.length();
std::cout << name[0];
```

| Phương thức | Ý nghĩa |
|---|---|
| `.length()` / `.size()` | Độ dài chuỗi (số phần tử char/code unit, không nhất thiết số ký tự Unicode hiển thị) |
| `.empty()` | Chuỗi rỗng? |
| `.find("abc")` | Tìm chuỗi con; không tìm thấy trả `std::string::npos` |
| `.substr(pos, count)` | Lấy chuỗi con |
| `+=` | Nối chuỗi |

### 07.5. Chỉ số mảng và `std::size_t`

```cpp
for (std::size_t i = 0; i < players.size(); ++i)
{
    std::cout << players[i].name << '\n';
}
```

`container.size()` trả về kiểu số nguyên không dấu (thường là `std::size_t`). Không mặc nhiên so sánh `int` với `size()` vì có thể gặp warning signed/unsigned và bug khi giá trị âm.

---

## 08. STRUCT, ENUM CLASS, REFERENCE

### 08.1. `struct` — nhóm dữ liệu

```cpp
#include <string>

enum class CharacterClass { Knight, Mage, Archer };

struct Player
{
    std::string name;
    CharacterClass role;
    int health;
    int maxHP;
};

Player knight{"Knight", CharacterClass::Knight, 100, 100};
std::cout << knight.health;
```

- `struct` tạo kiểu dữ liệu riêng.
- Truy cập thành viên bằng dấu `.`.
- `struct` trong C++ **có thể chứa constructor và method**, không chỉ dữ liệu; khác `class` chủ yếu ở quyền truy cập mặc định và kiểu kế thừa mặc định (Bài 11).

### 08.2. `enum class` — trạng thái có tên

```cpp
enum class CharacterClass
{
    Knight,
    Mage,
    Archer
};

CharacterClass role = CharacterClass::Mage;
```

- Truy cập giá trị bằng `CharacterClass::Mage`.
- Không tự động chuyển ngầm sang `int` như unscoped enum thông thường.
- Hữu ích cho trạng thái, loại nhân vật, weapon category, game mode…

### 08.3. Reference

```cpp
int hp = 100;
int& ref = hp;
ref = 80;  // hp giờ là 80
```

- Reference phải được khởi tạo để tham chiếu đối tượng thích hợp.
- `int& ref = hp` là tên khác cho `hp`, không phải con trỏ.
- `ref = anotherValue` **gán giá trị** vào đối tượng đang tham chiếu; không chuyển reference sang đối tượng khác.

```cpp
void ApplyDamage(Player& player, int damage)
{
    if (damage <= 0) return;
    player.health = damage >= player.health ? 0 : player.health - damage;
}

bool IsAlive(const Player& player)
{
    return player.health > 0;
}
```

- `Player&`: sửa đối tượng gốc.
- `const Player&`: chỉ đọc qua tham chiếu, tránh copy đối tượng lớn.
- Tránh trả về reference đến biến cục bộ đã hết vòng đời.

---

## 09. POINTER (CON TRỎ)

### 09.1. Giá trị, địa chỉ, dereference

```cpp
int health = 100;
int* ptr = &health;

std::cout << health;  // 100
std::cout << &health; // Địa chỉ của health
std::cout << ptr;     // Địa chỉ đang lưu trong ptr
std::cout << *ptr;    // 100

*ptr = 50;            // health thành 50
```

| Cú pháp | Ý nghĩa |
|---|---|
| `T* ptr` | Khai báo biến con trỏ đến T |
| `&object` | Lấy địa chỉ object (address-of) |
| `ptr` | Giá trị địa chỉ mà ptr lưu |
| `*ptr` | Dereference — truy cập đối tượng được trỏ tới |
| `ptr = &other` | Đổi đích trỏ của ptr |
| `nullptr` | Giá trị con trỏ null, không trỏ đến đối tượng |
| `ptr->member` | Truy cập thành viên qua con trỏ |
| `(*ptr).member` | Tương đương `ptr->member` |

```cpp
Player* target = &knight;
target->health = 80;
// target->health == (*target).health
```

`*` xuất hiện trong **khai báo** (`int* p`) khác ý nghĩa với phép **dereference** (`*p`). `&` xuất hiện trong khai báo reference (`int&`) khác toán tử lấy địa chỉ (`&x`).

### 09.2. `nullptr` và kiểm tra trước khi dùng

```cpp
Player* target = nullptr;
if (target != nullptr)
{
    PrintPlayer(*target);
}
```

- `*nullptr` có hành vi không xác định; thường crash.
- Pointer không null **vẫn có thể không hợp lệ** nếu đối tượng đã chết hoặc địa chỉ sai.
- Truyền `HealPlayer(nullptr, 30)` không làm biến `target` ở chỗ gọi tự chuyển thành nullptr.

### 09.3. Pointer vs Reference

| Reference (`T&`) | Pointer (`T*`) |
|---|---|
| Phải gắn với đối tượng khi tạo | Có thể là `nullptr` |
| Không thể “rebind” | Có thể đổi địa chỉ lưu |
| Dùng cú pháp thành viên `obj.member` | Dùng `ptr->member` |
| Phù hợp khi tham số phải tồn tại | Phù hợp khi sự vắng mặt/đổi đích có ý nghĩa |

---

## 10. STACK, HEAP, DYNAMIC MEMORY, SMART POINTER

### 10.1. Vòng đời và nơi lưu trữ

```cpp
int hp = 100;              // Automatic storage duration (thường stack)
int* ptr = new int{100};  // Cấp phát động (thường heap)
delete ptr;
ptr = nullptr;
```

Cần phân biệt **thời gian sống/lifetime** của đối tượng với vị trí bộ nhớ triển khai. Cách nói stack/heap rất hữu ích để bắt đầu nhưng không bao trùm toàn bộ storage model của C++.

### 10.2. `new`, `delete`, `new[]`, `delete[]`

```cpp
int* p = new int{42};
delete p;
p = nullptr;

int* array = new int[5]{};
delete[] array;
array = nullptr;
```

- Mỗi `new` cấp phát động cần có cơ chế giải phóng quyền sở hữu phù hợp.
- Ghép `new[]` với `delete[]`.
- `delete` hai lần cùng vùng nhớ → hành vi không xác định.
- Sau `delete`, con trỏ trỏ đến vùng nhớ đã giải phóng trở thành **dangling** cho đến khi được gán lại; việc gán một con trỏ thành null không sửa các alias khác.

### 10.3. Lỗi bộ nhớ

| Lỗi | Bản chất |
|---|---|
| Memory leak | Tài nguyên được cấp phát nhưng không được giải phóng đúng cách |
| Dangling pointer | Con trỏ còn giữ địa chỉ của đối tượng đã hết lifetime |
| Double delete | Hủy/giải phóng hai lần cùng đối tượng cấp phát |
| Null dereference | Dereference con trỏ null |
| Out-of-bounds | Truy cập vượt phạm vi mảng/container |

**`ptr == nullptr` không chứng minh không có memory leak.** Nếu gán `nullptr` trước `delete` và làm mất con trỏ duy nhất, đối tượng cấp phát có thể bị leak.

### 10.4. RAII và `std::unique_ptr`

RAII = gắn quyền quản lý tài nguyên với vòng đời của một đối tượng. Khi đối tượng quản lý bị hủy, tài nguyên được giải phóng.

```cpp
#include <memory>

auto player = std::make_unique<Player>(/* tham số constructor */);
player->TakeDamage(20); // Gọi thành viên qua smart pointer
PrintPlayer(*player);    // Chuyển thành tham chiếu Player& / const Player&
```

| Cú pháp | Ý nghĩa |
|---|---|
| `std::unique_ptr<T>` | Smart pointer sở hữu độc quyền T |
| `std::make_unique<T>(...)` | Tạo T và trả unique_ptr sở hữu nó |
| `ptr->method()` | Truy cập thành viên T |
| `*ptr` | Truy cập đối tượng T |
| `ptr.get()` | Lấy raw pointer **không chuyển quyền sở hữu** |
| `{ ... }` scope | Khi unique_ptr cục bộ hết lifetime, đối tượng sở hữu được hủy tự động |

```cpp
{
    auto player = std::make_unique<Player>("Knight", CharacterClass::Knight, 100);
    // Ví dụ này dùng constructor Player đã được thiết kế trong Bài 11.
} // Destructor của unique_ptr chạy; Player bị hủy
```

`std::shared_ptr` và `std::weak_ptr` mới chỉ được **giới thiệu tên và vai trò**, chưa học kỹ cơ chế đếm tham chiếu/cycle.

### 10.5. Bài học thiết kế

Không cần viết `player->health` ở `main()` nếu đã có phương thức `player->Heal()` hoặc `PrintPlayer()`. Dùng cú pháp nào phải xuất phát từ nhiệm vụ thực tế; bài tập đôi lúc yêu cầu cú pháp chỉ để luyện thao tác, không có nghĩa luôn nên dùng trong sản phẩm.

---

## 11. CLASS, ENCAPSULATION, CONSTRUCTOR

### 11.1. `class` và quyền truy cập

```cpp
class Player
{
private:
    int health;
    int maxHP;

public:
    Player(int maximumHP);
    void TakeDamage(int damage);
    int GetHealth() const;
};
```

- `class`: Kiểu dữ liệu có thuộc tính và phương thức; thành viên mặc định `private`.
- `public`: Bên ngoài có thể sử dụng.
- `private`: Bên ngoài và class con không thể truy cập trực tiếp; phương thức trong cùng class truy cập được.
- `protected`: Truy cập được trong class và class con theo quy tắc access (đã giới thiệu khi học kế thừa).
- **Encapsulation:** Bảo vệ trạng thái và điều khiển cách thay đổi thông qua giao diện công khai.

### 11.2. Constructor + member initializer list

`Player.cpp`:

```cpp
#include "Player.h"

Player::Player(int maximumHP)
    : health(maximumHP), maxHP(maximumHP)
{
}
```

- Constructor có tên giống class, **không có kiểu trả về**.
- Phần `: health(...), maxHP(...)` trực tiếp khởi tạo các member trước khi thân constructor chạy.
- Thứ tự khởi tạo member là **thứ tự khai báo trong class**, không nhất thiết thứ tự liệt kê sau dấu `:`.
- Với `const` member hoặc reference member, cần khởi tạo thích hợp thay vì chờ gán trong thân constructor.

### 11.3. Member functions, getters, `const`

```cpp
void Player::TakeDamage(int damage)
{
    if (damage <= 0) return;
    health = damage >= health ? 0 : health - damage;
}

int Player::GetHealth() const
{
    return health;
}
```

- `Player::TakeDamage`: Định nghĩa phương thức thành viên của Player ngoài class.
- `GetHealth() const`: Phương thức không được thay đổi member không `mutable` qua `this` (và có thể gọi trên const Player).
- `const std::string& GetName() const`: Trả tham chiếu chỉ đọc để tránh copy chuỗi, nhưng tham chiếu chỉ tồn tại an toàn khi Player còn sống.
- Đặt phương thức thay đổi trạng thái (`TakeDamage`, `Heal`) không `const`.

### 11.4. Lợi ích thiết kế

Trước: `ApplyDamage(Player&, int)` là hàm độc lập.  
Sau: `player.TakeDamage(20)` thuộc về class. Khi HP là private, bên ngoài không trực tiếp gán `health = -100`, giúp class tự kiểm soát quy tắc HP.

Không bắt buộc tất cả hàm đều phải trở thành member. Ví dụ `PrintPlayer(const Player&)` vẫn có thể là hàm độc lập sử dụng getter.

---

## 12. KẾ THỪA, ĐA HÌNH, THIS, DESTRUCTOR

### 12.1. Kế thừa

```cpp
class Enemy
{
public:
    void Move() { /* ... */ }
};

class Boss : public Enemy
{
public:
    void SpecialAttack() { /* ... */ }
};
```

`class Boss : public Enemy` = Boss công khai kế thừa Enemy. Quan hệ nên thể hiện **Boss là một loại Enemy**, không đơn thuần để tái sử dụng vài dòng code.

### 12.2. Tại sao cần `virtual`?

Không virtual:

```cpp
class Animal
{
public:
    void MakeSound() const { std::cout << "Unknown\n"; }
};

class Dog : public Animal
{
public:
    void MakeSound() const { std::cout << "Woof\n"; }
};

Dog dog;
Animal& animal = dog;
animal.MakeSound();  // Unknown (theo kiểu tĩnh Animal&)
```

Có virtual và override:

```cpp
class Animal
{
public:
    virtual void MakeSound() const { std::cout << "Unknown\n"; }
    virtual ~Animal() = default;
};

class Dog : public Animal
{
public:
    void MakeSound() const override { std::cout << "Woof\n"; }
};

Dog dog;
Animal& animal = dog;
animal.MakeSound();  // Woof (dispatch động tới Dog)
```

| Từ khóa | Ý nghĩa |
|---|---|
| `virtual` | Cho phép lời gọi qua pointer/reference lớp cha dispatch theo kiểu động của object |
| `override` | Bắt compiler xác minh đây là ghi đè một hàm virtual hợp lệ |
| `: public Base` | Kế thừa công khai từ Base |
| `Base&` / `Base*` | Tham chiếu/con trỏ kiểu lớp cha có thể chỉ vào derived object |

**Override khác overload**: overload = các hàm cùng tên khác danh sách tham số; override = method con ghi đè virtual method của cha phù hợp chữ ký.

### 12.3. Constructor và destructor khi kế thừa

```cpp
class Animal
{
public:
    explicit Animal(const std::string& name) : name(name) {}
    virtual ~Animal() { std::cout << "Animal destroyed\n"; }
private:
    std::string name;
};

class Dog : public Animal
{
public:
    Dog() : Animal("Dog") {} // Phải khởi tạo phần lớp cha
    ~Dog() override { std::cout << "Dog destroyed\n"; }
};
```

Thứ tự: **khởi tạo base trước derived; hủy derived trước base**. Với trường hợp xóa derived qua base pointer, public virtual destructor của base bảo đảm cách hủy đúng cho dạng sở hữu này.

```cpp
std::unique_ptr<Animal> animal = std::make_unique<Dog>();
// Khi unique_ptr hủy Dog: ~Dog() rồi ~Animal()
```

### 12.4. Con trỏ `this`

```cpp
class Animal
{
private:
    std::string name;
public:
    void SetName(const std::string& name)
    {
        this->name = name; // member = parameter
    }
};
```

- `this` là con trỏ tới object hiện tại trong phương thức thành viên không static.
- `this->health` thường tương đương `health` nếu không trùng tên biến.
- `*this` là object hiện tại theo tham chiếu; sẽ mở rộng khi cần.

### 12.5. Lưu ý chưa học sâu

- `virtual ... = 0` (pure virtual / abstract class) mới **được nhắc là nội dung tiếp theo**, chưa thực hành.
- Object slicing, nhiều loại inheritance phức tạp, RTTI sâu: chưa học.
- Không phải mọi method đều cần `virtual`; dùng khi cần dispatch động thực tế.

---

## 13. TEMPLATES FUNDAMENTALS

### 13.1. Function Template

```cpp
template <typename T>
T GetMax(T a, T b)
{
    return a > b ? a : b;
}

int a = GetMax(10, 20);                // T được suy luận là int
float b = GetMax(5.5f, 3.2f);        // T = float
float c = GetMax<float>(10, 5.5f); // Ghi rõ T = float
```

- `template <typename T>` khai báo tham số kiểu tổng quát.
- `T` đại diện cho kiểu được chỉ định/suy luận khi **instantiation**.
- Compiler làm việc với kiểu xác định lúc compile-time; không phải runtime dynamic typing.

Ví dụ dễ lỗi:

```cpp
// GetMax(10, 5.5f);  // Không suy luận được cùng một T từ int và float
GetMax<float>(10, 5.5f); // Hợp lệ: chuyển 10 thành float
```

### 13.2. Class Template

```cpp
template <typename T>
class Stat
{
private:
    T value;
public:
    explicit Stat(T initial) : value(initial) {}
    T GetValue() const { return value; }
};

Stat<int> hp(100);
Stat<float> speed(5.5f);
```

Class Template đã **được giảng bằng ví dụ**, nhưng bài tập thực hành chủ yếu là **Function Template**; chưa nên tự coi đã giỏi thiết kế class template nâng cao.

### 13.3. `std::array`/`std::vector` là template

```cpp
std::vector<int> values;
std::array<float, 3> threeNumbers;
```

`std::array<float, 3>` gồm tham số kiểu `float` và tham số giá trị hằng `3`.

### 13.4. Template thường định nghĩa trong header

`GameMath.h`:

```cpp
#pragma once

template <typename T>
T GetMax(T a, T b)
{
    return a > b ? a : b;
}

template <typename T>
T ClampValue(T value, T minValue, T maxValue)
{
    if (value < minValue) return minValue;
    if (value > maxValue) return maxValue;
    return value;
}
```

Compiler thường phải thấy định nghĩa template khi cần instantiation, nên các template thông thường được định nghĩa trong header. Có ngoại lệ/cách khác nhưng chưa học.

### 13.5. Bài tập GameMath đã làm

```cpp
int health = ClampValue<int>(150, 0, 100);           // 100
float speed = ClampValue<float>(-2.5f, 0.0f, 10.0f); // 0.0f
```

Bài gốc từng để giới hạn speed là `100.0f` thay vì yêu cầu `10.0f`: đây là sai yêu cầu test, **không phải sai logic template**.

> Ghi nhớ: Standard C++17 đã cung cấp `std::clamp` trong `<algorithm>`; trong code sản phẩm, nên ưu tiên thư viện chuẩn khi phù hợp. Tự viết ClampValue trong giáo trình chỉ nhằm luyện template.

---

## 14. BẢNG TRA CỨU NHANH CÁC CÚ PHÁP

> Bảng này tập trung vào **đã học**. Một số từ khóa có nhiều ý nghĩa theo ngữ cảnh — hãy đọc lại chương tương ứng nếu nhầm lẫn.

### 14.1. Cấu trúc và biến

| Cú pháp | Nhắc nhanh |
|---|---|
| `#include <header>` | Include khai báo thư viện/hệ thống |
| `#include "Local.h"` | Include header của dự án |
| `#pragma once` | Ngăn header được include lặp trong cùng TU |
| `int main() {}` | Entry point |
| `int x = 3;` | Khai báo và khởi tạo |
| `int x{3};` | Brace initialization |
| `const int x = 3;` | Không được sửa qua biến x |
| `constexpr int x = 3;` | Hằng có yêu cầu compile-time |
| `auto x = 3;` | Compiler suy luận kiểu x |
| `std::cout << x;` | Xuất |
| `std::cin >> x;` | Nhập |
| `std::getline(std::cin, s);` | Nhập một dòng |
| `std::boolalpha` | Xuất bool dạng true/false |
| `static_cast<float>(x)` | Ép kiểu tường minh cơ bản |

### 14.2. Điều kiện, vòng lặp, hàm

| Cú pháp | Nhắc nhanh |
|---|---|
| `if (cond) {}` | Nếu điều kiện đúng |
| `else if (cond) {}` | Nhánh kiểm tra tiếp |
| `else {}` | Nhánh mặc định |
| `switch (x) { case 1: ... }` | Phân nhánh theo giá trị |
| `break;` | Thoát switch/vòng lặp gần nhất |
| `continue;` | Sang lượt lặp tiếp |
| `for (int i=0; i<n; ++i) {}` | Vòng lặp có bộ đếm |
| `while (cond) {}` | Kiểm tra trước khi lặp |
| `do {} while (cond);` | Chạy ít nhất một lượt |
| `for (const auto& e : items) {}` | Duyệt không copy object lớn |
| `return x;` | Trả giá trị từ hàm |
| `void F()` | Hàm không trả giá trị |
| `int F(int a);` | Khai báo hàm |
| `int F(int a) { return a; }` | Định nghĩa hàm |
| `cond ? a : b` | Toán tử ba ngôi |

### 14.3. Container và OOP

| Cú pháp | Nhắc nhanh |
|---|---|
| `std::array<int, 3>` | Mảng cố định 3 int |
| `std::vector<int>` | Vector các int |
| `v.push_back(x)` | Thêm phần tử cuối |
| `v.pop_back()` | Xóa phần tử cuối |
| `v.size()` | Số phần tử |
| `v.empty()` | Container rỗng? |
| `v.at(i)` | Truy cập có kiểm tra phạm vi |
| `struct S { ... };` | Định nghĩa struct |
| `enum class Mode { Idle, Run };` | Enum có phạm vi tên |
| `class C { ... };` | Định nghĩa class |
| `public:` / `private:` | Phân quyền thành viên |
| `C::Method()` | Định nghĩa member ngoài class |
| `C(...) : x(...){}` | Constructor + initializer list |
| `~C()` | Destructor |
| `int Get() const` | Method chỉ đọc trạng thái qua `this` |
| `this->member` | Thành viên object hiện tại |
| `class Dog : public Animal` | Kế thừa công khai |
| `virtual void F()` | Hàm dispatch động |
| `void F() override` | Xác minh override |
| `virtual ~Base()` | Destructor virtual của base |

### 14.4. Reference, Pointer, Memory, Template

| Cú pháp | Nhắc nhanh |
|---|---|
| `int& ref = x;` | Tham chiếu tới x |
| `const T& ref = obj;` | Tham chiếu chỉ đọc |
| `T* ptr = &obj;` | Con trỏ giữ địa chỉ obj |
| `*ptr` | Dereference |
| `ptr->field` | Truy cập thành viên qua pointer |
| `(*ptr).field` | Tương đương ptr->field |
| `ptr = nullptr;` | Đặt thành con trỏ null |
| `new T{...}` | Tạo đối tượng cấp phát động |
| `delete ptr;` | Hủy đối tượng cấp phát bằng new và giải phóng vùng nhớ tương ứng |
| `delete[] array;` | Giải phóng array cấp phát bằng new[] |
| `std::unique_ptr<T>` | Sở hữu độc quyền T |
| `std::make_unique<T>(args...)` | Tạo unique_ptr sở hữu T |
| `unique.get()` | Lấy raw pointer không sở hữu |
| `template <typename T>` | Tham số kiểu cho template |
| `GetMax<int>(a, b)` | Instantiation với T = int |

---

## 15. LỖI HAY GẶP VÀ TƯ DUY VIẾT CODE

### 15.1. Lỗi điển hình

1. **Dùng `=` thay `==`** ở điều kiện.
2. **Chia số nguyên** trước khi gán cho `float` (`float p = hp / maxHP` không giữ phần lẻ).
3. **In HP trước khi giới hạn về 0**: dễ hiển thị HP âm khi damage quá lớn.
4. **`health != 0` để xác định còn sống**: nếu health âm thì vẫn true; thường cần `health > 0`.
5. **Đặt dữ liệu ở hai mảng song song** mà không giữ index đồng bộ: nên dùng struct/class `Player`.
6. **Viết hàm trả HP âm** rồi trông cậy mọi nơi gọi tự sửa: nên làm rõ hậu điều kiện ngay trong hàm.
7. **Sai signed/unsigned** khi so sánh `int i` và `container.size()`.
8. **Sao chép `std::string`/Player không cần thiết** trong range-based for: cân nhắc `const auto&`.
9. **Dereference `nullptr`/dangling pointer**.
10. **`ptr = nullptr` không tương đương `delete ptr`**.
11. **`new[]` nhưng `delete`** (thay vì `delete[]`).
12. **Định nghĩa hàm thường trong header rồi include ở nhiều `.cpp`** gây lỗi liên kết khi không cấu hình đúng.
13. **Đưa template definition vào `.cpp`** nhưng không có explicit instantiation cần thiết: nơi sử dụng không nhìn thấy định nghĩa.
14. **Dùng `virtual` chỉ vì method nằm trong class**: chỉ thực sự cần dispatch động.
15. **Viết mã không có mục đích chức năng chỉ để xuất hiện một cú pháp**: phần luyện cú pháp nên tách khỏi quyết định thiết kế.

### 15.2. Checklist khi tự review code

- Chương trình có **đúng yêu cầu** hay chỉ ra đúng output với dữ liệu mẫu?
- Kiểm thử biên: HP 0, damage âm, damage lớn, vector rỗng, pointer null.
- Đầu vào đã được kiểm tra khi cần chưa? Có biến nào chưa khởi tạo?
- Mỗi hàm có trách nhiệm rõ ràng không? Logic và UI có bị trộn vô lý không?
- Class có giữ được bất biến (ví dụ `0 <= hp <= maxHP`) không?
- Hàm chỉ đọc có dùng `const`/`const&` hợp lý không?
- Có sở hữu bộ nhớ bằng `new/delete` thủ công không cần thiết không?
- Header có khai báo đầy đủ và đúng các include cần thiết không?
- Compiler có warning không? Đã chạy với nhiều bộ input chưa?

### 15.3. Quy tắc tối ưu ở giai đoạn này

- Ưu tiên **đúng và rõ ràng** trước khi tối ưu vi mô.
- Range-based for, `auto`, `std::array` không mặc nhiên “chậm/tốn tài nguyên” hơn mọi cách viết thủ công; hiểu kiểu, bản sao và compile-time trước.
- Dùng `constexpr` để xác lập thuộc tính compile-time, không phải vì tin nó luôn nhanh hơn `const`.
- Không biến mọi phép nhân/chia thành bit shift.
- Dùng profiler/debugger để xác nhận bottleneck khi bắt đầu tối ưu dự án thật.

---

## 16. NHỮNG BÀI TẬP ĐÃ THỰC HÀNH

| Buổi học | Bài thực hành | Khái niệm được kiểm tra |
|---|---|---|
| 01 | Player Information | Biến, cin/cout, string, % HP |
| 02 | Damage System | `const`, `constexpr`, `auto`, `static_cast` |
| 03 | Player Combat System | Toán tử, bool, logic, gán kết hợp |
| 04 | Combat & Potion System | `if/else`, `switch`, giới hạn HP, ternary |
| 05 | Training Arena | `for`, `continue`, `break`, `do-while` chơi lại |
| 06 | Refactor Training Arena | Function declaration/definition, return, void |
| 06.5 | Modular Training Arena | `.h`, `.cpp`, `#include`, compiler/linker |
| 07 | Party Management | `std::array`, `std::vector`, range-based for |
| 08 | Character Data System | `struct Player`, `enum class`, `Player&`, `const Player&` |
| 09 | Pointer-Based Healing | `Player*`, `->`, `nullptr`, đổi đích trỏ |
| 10 | Dynamic Character Manager | `new/delete`, `std::unique_ptr`, `.get()` |
| 11 | Player Class System | Constructor, encapsulation, getter, method const |
| 12.1 | Animal / Dog Virtual Test | Kế thừa, `virtual`, `override`, base pointer |
| 12.2 | Animal / Dog Lifetime | Constructor cha, destructor ảo, `this`, unique_ptr |
| 13 | Generic Game Math | Function template, explicit template args, clamp |

**Năng lực đã thể hiện qua bài nộp:** Tự viết console chương trình nhỏ, tổ chức thành file nguồn/header, xử lý gameplay đơn giản, dùng con trỏ/tham chiếu, sử dụng class và template mức căn bản. **Chưa thể kết luận đạt Junior C++/Unreal chỉ dựa trên bài tập này.**

---

## 17. NHỮNG NỘI DUNG CHƯA HỌC VÀ LỘ TRÌNH TIẾP

### 17.1. Đã học và chưa học — phân biệt rõ

- **Đã học và có bài nộp:** Bài 01–13 như bảng trên.
- **Đã được giới thiệu nhưng chưa học sâu:** `std::shared_ptr`/`std::weak_ptr`, class template nâng cao, cast ngoài `static_cast`, compiler/linker sâu, debugger thực hành, `protected` sâu, enum/cast nâng cao, `[[fallthrough]]`.
- **Chưa học có hệ thống:** `static`, `namespace` chi tiết, const pointer (`const T*` vs `T* const`), forward declarations, preprocessor/macros, copy/move semantics, lambda/captures, debugging workflow, các dạng casting còn lại.

### 17.2. Kế hoạch cầu nối trước Unreal C++

| Bài | Nội dung | Trạng thái |
|---|---|---|
| 13 | Templates Fundamentals | **Hoàn thành** |
| 14 | Static, Const nâng cao, Namespaces | Chưa học |
| 14.5 | Casting & Type Conversions (`static_cast`, `dynamic_cast`, `const_cast`, `reinterpret_cast`) | **Được bổ sung, chưa học** |
| 15 | Preprocessor, Macros, Forward Declarations, Include Dependencies | Chưa học |
| 16 | Copy/Move Semantics, Lambdas cơ bản | Chưa học |
| 17 | Visual Studio Debugging + tổng kiểm tra C++ | Chưa học |

### 17.3. Ranh giới với Unreal Engine C++

Đây là giáo trình **Standard C++**, chưa dạy thực hành Unreal. Trong cuộc trò chuyện khác sẽ học: `AActor`, `UObject`, `UActorComponent`, reflection (`UCLASS`, `UPROPERTY`, `UFUNCTION`), UBT/UHT, `TArray`, `TMap`, `FString`, `TObjectPtr`, `Cast<T>()`, garbage collection và C++/Blueprint integration.

**Chỉ lập file handoff C++ → Unreal sau khi hoàn thành các bài cầu nối và đánh giá đủ khả năng chuyển tiếp.**

---

## KẾT LUẬN NGẮN

Bạn đã xây dựng nền tảng C++ từ cấu trúc chương trình, kiểu dữ liệu, điều kiện, vòng lặp, hàm và file cho tới pointer, reference, memory, class, inheritance, virtual và template. Khi cần ôn cú pháp, xem **Phần 14**; khi muốn hiểu tại sao phải dùng, đọc lại chương tương ứng; khi muốn nhớ công việc thực tế, xem **Phần 16**.

**Không coi toàn bộ C++ nâng cao là đã học. Tiếp tục từ Bài 14 khi sẵn sàng.**
