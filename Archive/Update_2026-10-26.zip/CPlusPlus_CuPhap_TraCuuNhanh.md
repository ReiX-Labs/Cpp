# C++ QUICK REFERENCE — CÚ PHÁP & Ý NGHĨA

**Đi kèm giáo trình:** `CPlusPlus_KienThuc_Bai01-13.md`  
**Phạm vi:** Nội dung đã học từ Bài 01–13. **Casting nâng cao và Bài 14–17 chưa học.**

> Khi chỉ muốn tra cứu cú pháp, mở file này. Khi cần giải thích bản chất, đọc lại chương liên quan trong giáo trình đầy đủ.

## 1. Cấu trúc, nhập/xuất

| Cú pháp | Ý nghĩa / lưu ý |
|---|---|
| `#include <iostream>` | Sử dụng khai báo nhập/xuất C++ |
| `#include <string>` | Sử dụng `std::string` |
| `#include <array>` | Sử dụng `std::array` |
| `#include <vector>` | Sử dụng `std::vector` |
| `#include <memory>` | Sử dụng `std::unique_ptr`, `std::make_unique` |
| `#include "Arena.h"` | Include header của project |
| `#pragma once` | Tránh header bị include lặp trong cùng TU |
| `int main() { ... }` | Entry point |
| `return 0;` | Kết thúc `main` thành công |
| `std::cout << x;` | Xuất dữ liệu |
| `std::cin >> x;` | Nhập dữ liệu |
| `std::getline(std::cin, s);` | Đọc cả dòng vào chuỗi |
| `std::boolalpha` | Hiển thị bool thành `true`/`false` |
| `'\n'` / `"\n"` | Xuống dòng |
| `//` / `/* ... */` | Comment một/nhiều dòng |

## 2. Biến, kiểu, hằng, casting đã học

| Cú pháp | Ý nghĩa |
|---|---|
| `int hp = 100;` | Số nguyên |
| `float speed = 5.5f;` | Số thực float |
| `double d = 0.5;` | Số thực double |
| `bool alive = true;` | Đúng/sai |
| `char rank = 'A';` | Ký tự |
| `std::string name = "Mage";` | Chuỗi |
| `unsigned int flags = 0u;` | Số nguyên không dấu |
| `int hp{100};` | Brace initialization |
| `const int x = 3;` | Không sửa biến qua tên x |
| `constexpr int x = 3;` | Compile-time constant |
| `auto x = 3;` | Compiler suy luận kiểu `int` |
| `static_cast<float>(hp)` | Ép kiểu tường minh đã học |
| `std::size_t i = 0;` | Kiểu chỉ số/kích thước không dấu |

**Lưu ý:** `const int n = 3` đôi khi cũng hợp lệ ở ngữ cảnh constant expression. Đừng hiểu `const` = runtime, `constexpr` = nhanh hơn.

## 3. Toán tử

| Cú pháp | Ý nghĩa |
|---|---|
| `+ - * / %` | Cộng, trừ, nhân, chia, chia dư nguyên |
| `= += -= *= /= %=` | Gán và gán kết hợp |
| `== != > < >= <=` | So sánh |
| `&&` | Logic AND, short-circuit |
| `\|\|` | Logic OR, short-circuit |
| `!` | Logic NOT |
| `++x` / `x++` | Tăng trước / lấy giá trị cũ rồi tăng |
| `--x` / `x--` | Giảm trước / lấy giá trị cũ rồi giảm |
| `cond ? a : b` | Chọn một trong hai biểu thức |
| `& \| ^ ~` | Bitwise AND, OR, XOR, NOT |
| `<< >>` | Dịch bit trái/phải (trong ngữ cảnh số nguyên) |
| `&= \|= ^= <<= >>=` | Bitwise gán kết hợp |

## 4. Điều kiện và vòng lặp

```cpp
if (hp <= 0) { /* Dead */ }
else if (hp <= 30) { /* Critical */ }
else { /* Alive */ }

switch (type)
{
    case 1: /* ... */ break;
    default: break;
}

for (int i = 0; i < 5; ++i) { /* ... */ }
while (condition) { /* ... */ }
do { /* ... */ } while (condition);

for (const auto& item : items) { /* đọc, không copy object lớn */ }

break;    // Thoát vòng lặp / switch gần nhất
continue; // Bỏ qua phần còn lại của lượt lặp
```

## 5. Hàm & tham số

```cpp
int Add(int a, int b);          // Declaration
int Add(int a, int b)           // Definition
{
    return a + b;
}

void Print() { /* không có giá trị trả về */ }
void DamageCopy(int hp);        // Pass by value (bản sao)
void DamageRef(int& hp);        // Pass by reference (sửa gốc)
void PrintPlayer(const Player& p); // Chỉ đọc, tránh copy
void Heal(Player* p, int amount);  // Pointer param; có thể kiểm tra null
```

**Nhắc nhớ:** Các hàm cùng tên nhưng khác tham số là **overload**; `override` là việc khác.

## 6. Container và string

| Cú pháp | Ý nghĩa |
|---|---|
| `int hp[3]{};` | Mảng C-style 3 phần tử |
| `std::array<int, 3> hp{};` | Mảng cố định 3 int |
| `std::vector<int> values;` | Vector int kích thước thay đổi |
| `values.push_back(10);` | Thêm cuối |
| `values.pop_back();` | Xóa cuối (phải không rỗng) |
| `values.size()` | Số phần tử |
| `values.empty()` | Kiểm tra rỗng |
| `values.clear()` | Xóa tất cả |
| `values[i]` | Truy cập index, không kiểm tra biên |
| `values.at(i)` | Truy cập có kiểm tra biên |
| `name += " X"` | Nối chuỗi |
| `name.length()` | Độ dài chuỗi |
| `name.find("X")` | Tìm chuỗi con |
| `name.substr(pos, len)` | Lấy chuỗi con |

**Index bắt đầu từ 0.** Truy cập ngoài biên với `operator[]` là lỗi nguy hiểm.

## 7. Struct, enum, reference, pointer

```cpp
enum class Role { Knight, Mage, Archer };
Role role = Role::Mage;

struct Player
{
    std::string name;
    int health;
};

Player p{"Mage", 80};
std::cout << p.health; // . qua object

Player& ref = p;       // Reference tới p
const Player& r = p;   // Read-only reference
Player* ptr = &p;      // Pointer lưu địa chỉ p
ptr->health = 40;      // Member qua pointer
(*ptr).health = 50;    // Tương đương
ptr = nullptr;         // Con trỏ null
```

**Kiểm tra null trước khi dereference, và nhớ rằng non-null không có nghĩa pointer còn sống.**

## 8. Bộ nhớ, RAII, smart pointer

| Cú pháp | Ý nghĩa |
|---|---|
| `new int{42}` | Cấp phát một int động |
| `delete ptr;` | Giải phóng đối tượng cấp phát bằng new |
| `new int[5]{}` / `delete[] ptr;` | Cấp phát / giải phóng mảng động |
| `std::unique_ptr<Player>` | Sở hữu độc quyền Player |
| `std::make_unique<Player>(args...)` | Tạo và sở hữu Player |
| `unique->Method()` | Truy cập member qua unique_ptr |
| `*unique` | Lấy đối tượng Player qua dereference |
| `unique.get()` | Lấy raw pointer không sở hữu |

Không dùng `delete` thủ công cho đối tượng được quản lý bằng `unique_ptr`. **`ptr = nullptr` không giải phóng bộ nhớ.**

## 9. Class & OOP

```cpp
class Player
{
private:
    int health;
public:
    explicit Player(int hp) : health(hp) {} // Constructor
    int GetHealth() const { return health; } // Getter const
    void SetHealth(int health) { this->health = health; }
    ~Player() = default; // Destructor mặc định
};

class Animal
{
public:
    virtual ~Animal() = default;
    virtual void Speak() const { /* ... */ }
};

class Dog : public Animal
{
public:
    void Speak() const override { /* ... */ }
};
```

| Cú pháp | Ý nghĩa |
|---|---|
| `private:` / `public:` / `protected:` | Quyền truy cập |
| `ClassName::Function()` | Định nghĩa method ngoài class |
| `: member(value)` | Member initializer list |
| `this->member` | Thành viên của object hiện tại |
| `~ClassName()` | Destructor |
| `class Derived : public Base` | Kế thừa công khai |
| `virtual` | Cho phép dynamic dispatch |
| `override` | Compiler kiểm tra ghi đè virtual |
| `virtual ~Base()` | Hủy đúng dạng derived qua base pointer (trong mô hình phổ biến) |

## 10. Templates

```cpp
template <typename T>
T GetMax(T a, T b)
{
    return a > b ? a : b;
}

int a = GetMax(10, 20);                 // Compiler suy luận T=int
float b = GetMax<float>(10, 5.5f);    // Chỉ định T=float
```

- `template <typename T>`: mẫu với một tham số kiểu.
- `GetMax<int>`: phiên bản instantiation với `T = int`.
- `std::vector<int>` và `std::array<float, 3>` là class template trong STL.
- Định nghĩa function/class template thông thường đặt trong header để compiler có thể instantiation.

## 11. Visual Studio và những bài chưa học

| Phím | Chức năng |
|---|---|
| `Ctrl+F5` | Chạy không debug |
| `F5` | Chạy với debugger |
| `Ctrl+Shift+B` | Build |
| `F9` | Breakpoint |
| `F10`, `F11`, `Shift+F11` | Step Over, Step Into, Step Out |

**Chưa học hệ thống:** Bài 14 `static`, const pointer, namespaces; Bài 14.5 casting đầy đủ; Bài 15 preprocessor/forward declaration; Bài 16 copy/move/lambda; Bài 17 debugging & tổng kiểm tra. **Chưa chuyển sang Unreal C++ trong giáo trình này.**
