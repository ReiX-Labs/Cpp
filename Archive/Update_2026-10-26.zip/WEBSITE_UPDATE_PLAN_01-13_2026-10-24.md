# Kế hoạch cập nhật website theo giáo trình C++ 01–13

Ngày đối chiếu: **24/10/2026**. Trạng thái: **kế hoạch để duyệt, chưa triển khai**.

## 1. Kết luận và phạm vi

Dùng `Update/CPlusPlus_KienThuc_Bai01-13.md` làm nguồn chính cho **lộ trình Standard C++ 01–13**. Nội dung mới khá tốt, có cải thiện thực chất so với nguồn cũ, nhưng cần biên tập và hợp nhất có kiểm soát trước khi lên web. Không thay import trực tiếp, không nối nguyên toàn bộ tài liệu vào các bài cũ.

Lượt này chỉ đọc, đối chiếu, tra cứu nguồn kỹ thuật, kiểm tra các ví dụ trong thư mục tạm và tạo bản kế hoạch này. Không sửa tài liệu đầu vào, mã nguồn web, trạng thái học, commit, push hoặc deploy.

### Bằng chứng hiện trạng

- Local HEAD và GitHub `main`: `d6790e89fc892b6b3118dde8765362c20db9309b`; website trả HTTP 200, asset đang phục vụ `/Cpp/assets/index-B6vIaOL2.js`. Workflow của commit này đã thành công.
- Website vẫn import nguồn 01–09 trong `src/content/handoff.ts:1`; file 01–13 mới chưa được đưa vào nội dung hiển thị.
- Đã đọc cả nguồn 01–13, handoff 01–09, báo cáo `KNOWLEDGE_REVIEW_2026-10-23.md`, bộ nạp nội dung, điều hướng, tiến độ, ôn tập và dữ liệu câu hỏi/thẻ liên quan.
- `npm run check:handoff` đạt: 10 mục bài học, 5 tài nguyên, 76 mục tra cứu của phiên bản hiện tại. Đây là kiểm tra tích hợp cũ, không xác nhận nguồn 01–13 đã lên web.
- Phạm vi kiểm định tập trung vào Standard C++17 bài 01–13 và các phần cũ ảnh hưởng trực tiếp. Không coi đây là xác nhận toàn bộ nội dung Unreal hoặc mọi ví dụ nâng cao trong thư viện.
- Nguồn mới dùng trong lần đối chiếu có SHA-256 `8E6FEB469030BDEF0D0B913EE93ED00A5DE7A150DBB9D62C9BDB6317F0C62956`.
- Đã đọc thêm file đi kèm vừa xuất hiện trong `Update`: `CPlusPlus_CuPhap_TraCuuNhanh.md` (SHA-256 `CC3EFE850DC7D01AF5EF6AD5B75C746745BFBC03FA60CE0AD17525D8C01420C0`). File này là đầu vào bổ sung cho tra cứu, không thay đổi phạm vi kế hoạch hay trạng thái web.

## 2. Chính sách nguồn và nội dung

| Nguồn | Vai trò sau cập nhật |
|---|---|
| `Update/CPlusPlus_KienThuc_Bai01-13.md` | Nguồn chính về phạm vi đã học, trình tự buổi học và lý thuyết 01–13; sửa các điểm ở mục 4 trong bản nội dung biên tập cho web. |
| `Update/CPlusPlus_CuPhap_TraCuuNhanh.md` | Bổ sung tra cứu theo nhóm, gồm toán tử/string/OOP; đối chiếu với chương 14 và bảng đang dùng, không import như một bộ bài học khác. |
| `Update/CPP_Fundamentals_Review_01-09_AI_Handoff.md` | Giữ những tài nguyên hữu ích chưa được thay thế: Arena tích hợp, yêu cầu Healing, tự kiểm tra, lịch ôn, lịch sử điểm có nguồn. |
| `Cpp_Game_Dev_Reference.md` | Thư viện tham khảo mở rộng. Sửa lỗi đã xác minh; không dùng toàn bộ 56 mục để suy người học đã học hết. |
| Ngân hàng quiz/challenge/flashcard | Nội dung dẫn xuất phải khớp lý thuyết chuẩn hóa, cùng phạm vi và điều kiện của ví dụ. |

Đề xuất tạo một lớp nội dung chuẩn hóa, mỗi chủ đề có ID ổn định, nguồn gốc và liên kết bài. Trang học, phần cơ bản trong thư viện và bảng tra cứu dùng chung nội dung này. Không giữ hai bản lý thuyết dài về cùng một chủ đề rồi sửa riêng từng bản.

Giữ file trong `Update` như tài liệu đầu vào để đối chiếu các lần bổ sung sau. Những sửa chữa/di chuyển khi biên tập cần có bảng ghi nhận; không âm thầm ghi đè nguồn người dùng vừa cung cấp.

## 3. Ánh xạ bài học và mức thay đổi

Số bài học, số chương markdown và số mục thư viện là ba hệ riêng. Các số ở cột thư viện dưới đây là ID `/lesson/:id` hiện tại, không phải thứ tự khóa học mới.

| Bài trên lộ trình | Phần nguồn mới | Mục thư viện liên quan | Việc cập nhật |
|---|---|---|---|
| Chuẩn bị | 00 | 0, 1, 2, 43 | Thiết lập VS2022/C++17, compile/link/runtime; breakpoint cơ bản. Không tính là buổi học mới. |
| 01 | 01 | 0, 1 | Nhập/xuất; thêm xử lý nhập lỗi và nối `>>` với `getline` theo từng bước. |
| 02 | 02 | 3, 22, 46 | Hợp nhất biến, khởi tạo, const/constexpr/auto/static_cast; bổ sung narrowing trước quiz. |
| 03 | 03 | 3 | Toán tử, short-circuit, bitmask; dùng ví dụ không đòi hỏi pointer trước bài 09. |
| 04 | 04 | 4 | Điều kiện, switch, scope; tách rõ khỏi bài vòng lặp. |
| 05 | 05 | 4, 17 | Vòng lặp; range-for phức tạp chuyển tới 07/08/11 theo tiên quyết. |
| 06 | 06 | 5 | Hàm, return, overload, trách nhiệm; giới thiệu reference qua `int&`, mở rộng ở 08. |
| 06.5 | 06.5 | 1, 2, 41 | Ví dụ ba file dùng kiểu int; compile/link; giữ chi tiết lỗi hữu ích của handoff cũ. |
| 07 | 07 | 20, 49 | Array/vector/string cơ bản trong một bài; bổ sung size/capacity và cầu nối invalidation. |
| 08 | 08 | 5, 6, 12, 22 | Struct, enum class, reference/const reference; ví dụ Player và range-for ở đây. |
| 09 | 09 | 6 | Pointer/null/lifetime; giữ Healing và Arena tổng hợp của nguồn cũ. |
| 10 | 10 | 7, 8, 9, 10 | Lifetime, new/delete, ownership, RAII, unique_ptr; cập nhật khóa học bằng phần cơ bản đã học. |
| 11 | 11 | 12, 13 | Class, encapsulation, constructor, initializer list, const method; thống nhất Player. |
| 12.1 | 12.1 + 12.2 | 14, 15 | Kế thừa, virtual/override, static/dynamic dispatch; bài Animal/Dog Virtual Test. |
| 12.2 | 12.3 + 12.4 | 12, 13, 14, 15 | Constructor cha, destructor ảo, thứ tự hủy, this; bài Animal/Dog Lifetime. |
| 13 | 13 | 19, 41 | Function/class template cơ bản, deduction, template trong header, GameMath. |

Đây là **13 bài chính**, có buổi bổ sung 06.5 và bài 12 chia hai buổi; nếu mỗi buổi là một mục tiến độ thì có **15 mục**, cộng phần Chuẩn bị không tính tiến độ. Không tự đếm tất cả tiêu đề thành bài học.

Các phần 14–17 của file mới lần lượt là bảng tra cứu, lỗi thường gặp, lịch sử thực hành và lộ trình tương lai. Đặc biệt **chương markdown 14 không phải Bài 14 sắp học về static/const/namespace**.

### Nội dung phải giữ từ nguồn 01–09

- Healing với yêu cầu và ca kiểm tra: nguồn cũ dòng 781–798.
- Arena ba file dùng struct/array/reference/pointer và output: dòng 802–918. Ví dụ ba file kiểu int của nguồn mới không thay thế bài tổng hợp này.
- 23 câu tự kiểm tra và đáp án: dòng 975–1038; phân về bài tương ứng, vẫn giữ trang tổng hợp.
- Lịch ôn 20 phút: dòng 1042–1060.
- Điểm lịch sử có ghi rõ nguồn: dòng 956–969. Nguồn mới nói 01–13 đã học/có bài nộp, nhưng không cấp điểm mới cho mọi bài.
- Giải thích C2084 và ngoặc khởi tạo `std::array` khi còn phù hợp.

Trạng thái cũ của bài 09 là thông tin lịch sử. Hiển thị cập nhật **“đã học/có bài nộp theo tài liệu 24/10/2026”**, không tự kết luận đã chấm đạt, không tạo điểm/XP hoặc đánh dấu đã đọc trên trình duyệt.

## 4. Những điểm cần chỉnh trước khi nhập

### 4.1. Lỗi hoặc điều kiện còn thiếu trong nguồn mới

| Ưu tiên | Vị trí nguồn mới | Phát hiện | Cách xử lý đề xuất |
|---|---|---|---|
| Cao | 878–879 đối chiếu 903, 922–925 | `make_unique<Player>("Knight", role, 100)` nói dùng constructor bài 11, nhưng bài 11 chỉ có `Player(int maximumHP)`. | Sau bài 11 dùng `make_unique<Player>(100)` theo đúng class đã định nghĩa. Tại bài 10 dùng `make_unique<int>(100)` hoặc struct đã biết; không bắt người học đoán constructor. |
| Cao | 922–925, 956, 1296 | Constructor chấp nhận maxHP âm trong khi bài muốn bảo vệ `0 <= hp <= maxHP`. | Quy định đầu vào rõ ràng. Đề xuất ví dụ cơ bản chuẩn hóa maxHP âm về 0, khởi tạo health bằng maxHP; khi tính %HP phải xử lý maxHP=0. |
| Vừa | 1157–1162, 1176 | Chưa nêu điều kiện khoảng clamp hợp lệ. | Ghi `minValue <= maxValue`, kiểm tra dưới/trong/trên/đúng biên/khoảng một giá trị. Phân biệt hàm tự viết trả T với `std::clamp` trả `const T&`; ở ví dụ cơ bản nhận kết quả bằng giá trị. |
| Vừa | 798 | Cụm mã `*nullptr` được gọi là UB, nhưng viết literal này trực tiếp là lỗi biên dịch. | Viết “dereference con trỏ đang mang giá trị null”; ví dụ typed pointer chỉ để nhận diện lỗi, không chạy để đoán output. |
| Vừa | 516 | Diễn giải truyền theo giá trị bằng “sao chép” dễ bị áp cho mọi class. | Nói tham số là đối tượng riêng; ví dụ int hiện tại tạo bản sao. Chi tiết copy/move/elision để bài 16. |
| Vừa | 1238 | `C::Method()` được mô tả như cú pháp đầy đủ định nghĩa method. | Dùng `void C::Method() { ... }`, hoặc chỉ rõ đây là phần tên có định phạm vi. |

Đối chiếu: [Microsoft make_unique](https://learn.microsoft.com/en-us/cpp/standard-library/memory-functions?view=msvc-170#make_unique), [Core Guidelines về constructor và invariant](https://isocpp.github.io/CppCoreGuidelines/CppCoreGuidelines#Rc-ctor), [chuẩn clamp](https://eel.is/c++draft/alg.clamp), [toán tử unary *](https://eel.is/c++draft/expr.unary.op).

### 4.2. Bổ sung có giới hạn để học liền mạch

1. **I/O:** nguồn mới đã có phát hiện nhập lỗi (142–147), nhưng chưa có luồng phục hồi/EOF và ví dụ hoàn chỉnh `>>` rồi `getline`. Dạy nhập hợp lệ ở 01; thêm xử lý lỗi lặp ở 04–05, tránh dùng điều kiện/vòng lặp chưa giải thích ngay bài đầu.
2. **Tiên quyết:** short-circuit dùng số ở 03, pointer ở 09; range-for đơn giản ở 07, `Player&` ở 08, `TakeDamage()` ở 11. Indexed-for bài 07 dùng mảng int thay vì `players[i].name` (667–673).
3. **Vector:** thêm phân biệt size/capacity, reserve/resize; sang 09–10 nhắc địa chỉ/reference phần tử cũ mất hiệu lực khi realloc. Không chạy ví dụ UB để kết luận “máy vẫn chạy được”. [Quy định vector capacity](https://eel.is/c++draft/vector.capacity).
4. **Ownership:** unique_ptr không copy; `.get()` là mượn, không tự `delete` kết quả; pointer mượn chỉ dùng khi đối tượng còn sống. Giới thiệu giới hạn này ngay ở 10; cơ chế move đầy đủ để 16. [unique_ptr](https://eel.is/c++draft/unique.ptr.single).
5. **OOP:** phân biệt các phiên bản Animal/Dog là ví dụ độc lập; không gộp nhiều định nghĩa trùng vào một chương trình. Giải thích ngắn `explicit` và `= default` tại lần xuất hiện đầu tiên.
6. **Template:** nói rõ T phải hỗ trợ thao tác mà hàm dùng; ví dụ GetMax cần so sánh `>`. Không biến phần này thành khóa concepts/SFINAE. [Microsoft Templates](https://learn.microsoft.com/en-us/cpp/cpp/templates-cpp?view=msvc-170).

Các nội dung đã rõ và nên giữ: lifetime khác mô hình stack/heap; alias không được sửa khi chỉ đặt một pointer thành null; thứ tự initializer theo khai báo; const method đọc qua this; virtual destructor; thứ tự base/derived; template deduction cho int/float; định nghĩa template thường ở header.

File tra cứu riêng cần đồng bộ thêm: dòng 165 phải nói rõ **gán raw pointer thành null không giải phóng đối tượng**, còn gán `unique_ptr` thành null có thể hủy đối tượng đang sở hữu; dòng 198 có cùng vấn đề cú pháp định nghĩa method chưa đủ; các dòng 121–123 nên nhắc code unit, `npos` và điều kiện của substr. Class Player rút gọn ở 170–178 chỉ minh họa cú pháp, chưa bảo vệ HP hợp lệ; cần ghi nhãn để không mâu thuẫn bài encapsulation. [unique_ptr assignment](https://eel.is/c++draft/unique.ptr.single.asgn).

### 4.3. Các lỗi cũ vẫn phải sửa đồng thời

Nguồn mới đúng không tự sửa phần thư viện, quiz hoặc thẻ vẫn đang dùng dữ liệu cũ. Giữ các hạng mục của báo cáo 23/10 trong cùng đợt cập nhật:

- Challenge `Shape` xóa derived qua base không có virtual destructor nhưng chấm output cố định (`src/data/challenges.ts:105–112`); sửa mẫu hoặc đổi thành bài tìm lỗi.
- Wrapper FileHandle/Texture có destructor nhưng copy mặc định dễ giải phóng hai lần; dùng Rule of Zero hoặc chính sách sở hữu rõ.
- Không khẳng định compiler luôn sinh đủ mọi copy/move member; không nói mọi object sau move đều rỗng hoặc move luôn rẻ hơn copy.
- Không giới hạn RAII vào stack, không gọi std::array luôn là mảng stack, không nói smart pointer không bao giờ leak.
- `#pragma once` không giải quyết mọi multiple definition giữa nhiều translation unit.
- `assert` phụ thuộc NDEBUG; reserve chỉ bảo đảm trong giới hạn capacity; emplace_back không mặc nhiên nhanh hơn.
- Rà lại cast trong thư viện/thẻ: dynamic_cast pointer thất bại khác dynamic_cast reference; C-style cast không phải “thử mọi loại cast”.

Nguồn, vị trí và lý do chi tiết cho nhóm này nằm trong `Update/KNOWLEDGE_REVIEW_2026-10-23.md`. Không đánh dấu các lỗi đó đã sửa chỉ vì đưa bản 01–13 vào một trang mới.

## 5. Cấu trúc học đề xuất

Ba nơi có vai trò rõ ràng:

1. **Học theo bài 01–13:** là lộ trình chính của Dashboard, Tiếp tục học, trước/sau và tiến độ. Lý thuyết đầy đủ xuất hiện ngay trong bài.
2. **Thư viện kiến thức:** giữ 56 mục cũ, chia Standard C++ cơ bản/mở rộng và Unreal. Phần trùng tái sử dụng chủ đề chuẩn; nội dung nâng cao không tự tính vào khóa đã học.
3. **Tra cứu nhanh:** tìm cú pháp hoặc ý nghĩa, lọc theo bài/nhóm, mở thẳng phần lý thuyết liên quan.

Mỗi bài theo một mẫu: **mục tiêu → cần biết trước → lý thuyết → ví dụ có giải thích → lỗi thường gặp → tự kiểm tra → bài tự viết → tiêu chí hoàn thành**. Các mẫu chạy độc lập có đủ include/file và output; snippet có nhãn phụ thuộc; mẫu cố ý lỗi có nhãn compile error/UB.

Giữ cách học tự viết code rồi kiểm tra. Bài tập có yêu cầu và test/rubric, không tự hiện lời giải hoàn chỉnh hoặc coi tick “đã đọc” là đã thành thạo.

Chỉ ghi lộ trình dự kiến cho bài 14, 14.5, 15, 16, 17. Shared/weak sâu, pure virtual/abstract, slicing, copy/move, lambda, casting nâng cao và Unreal vẫn có nhãn chưa học/tra cứu mở rộng. Không đánh dấu chúng đã học chỉ vì xuất hiện trong thư viện.

## 6. Kế hoạch kỹ thuật theo giai đoạn

Các đường dẫn mới dưới đây là **đề xuất**, chưa được tạo.

| Giai đoạn | Công việc và khu vực dự kiến | Điều kiện hoàn tất |
|---|---|---|
| 1 — Chuẩn hóa nội dung | Lập manifest ở `src/content/course.ts`, nội dung theo chủ đề trong `src/content/course/`; ghi nguồn/section, prerequisite, trạng thái đã học/giới thiệu/mở rộng. Biên tập theo mục 4. | Đủ 15 mục học + Chuẩn bị + resources; không mất nội dung cũ cần giữ; mỗi mục có phạm vi rõ. |
| 2 — Đọc và hợp nhất nguồn | Thêm bộ đọc nguồn 01–13/manifest; chỉnh `handoff.ts`, `handoffParser.ts`, `integrateHandoff.ts`, `reference.ts` hoặc thay vai trò adapter bằng resolver theo chủ đề. | Không phụ thuộc vị trí chương hoặc ép ID thành số; nội dung trực tiếp của bài và thư viện thống nhất. |
| 3 — Luyện tập và tra cứu | Đồng bộ `quizzes.ts`, `challenges.ts`, `cards.ts`, `exercises.ts`, `SyntaxLookup.tsx`. | Mỗi bài có câu hỏi đúng phạm vi; 23 câu cũ có mapping; thêm memory/OOP/template; bảng tra cứu không mất chức năng đã có. |
| 4 — Luồng học và tiến độ | Chỉnh Dashboard, Sidebar, Topbar/search, trang học/Fundamentals, Review, App routes và store. | Điều hướng theo khóa; đường dẫn cũ còn hoạt động; dữ liệu đã lưu không mất; kết quả tìm kiếm phân biệt bài học và thư viện. |
| 5 — Kiểm định trước phát hành | Kiểm tra nội dung, code C++17, build web, trình duyệt desktop/mobile, dữ liệu lưu cũ; cập nhật CI. | Đạt toàn bộ tiêu chí mục 8; có bản xem trước và bản ghi thay đổi để kiểm tra. |
| 6 — Đưa lên web | Chỉ sau khi người dùng yêu cầu triển khai; commit/push theo quy trình hiện tại và kiểm tra GitHub Pages. | Xác nhận commit/asset được phục vụ và kiểm tra các bài mới trên web thật. |

### Những bẫy cần xử lý trong giai đoạn 2

- Đã chạy `parseHandoff` hiện tại với file mới: **0 chương**. Parser chỉ nhận H1 `# số-nguyên.`; nguồn mới dùng H2 và `06.5`.
- `parseReference` hiện tại cũng nhận **0 section** từ file mới vì không có cấu trúc Part H1 như nguồn thư viện. Không dùng nó làm đường tắt.
- Khóa ID là chuỗi, ví dụ `cpp-06-5`, `cpp-12-1`; số hiển thị là 06.5/12.1. Sắp xếp theo manifest, không sort số thực hay thứ tự chuỗi.
- Chỉ nâng parser regex chưa đủ: `integrateHandoff.ts` hardcode chương/tiểu mục cũ; studyResources trỏ số 12–16 cũ đã mang nghĩa khác ở nguồn mới.
- Buổi 12.2 phải lấy nguồn §12.3–12.4, không phải H3 12.2.
- Bảng mới có **64 dòng**, bảng hiện tại có **76 mục**; parser nhóm cũ không nhận H3 mới nên chỉ cho một nhóm. Bảng mới thêm memory/OOP/template nhưng thiếu nhiều toán tử, bitmask và thao tác string đang có.
- Con số 64 ở trên chỉ nói chương 14 trong giáo trình. File `CPlusPlus_CuPhap_TraCuuNhanh.md` riêng bổ sung nhiều nội dung đó, nhưng một số nhóm hàm/pointer/OOP/template nằm trong code block, không phải dòng bảng; parser bảng hiện tại không tự chuyển chúng thành mục tìm kiếm. Cần hợp nhất cả ba đầu vào trước khi chốt số mục cuối cùng.
- Hợp nhất bảng theo khóa ý nghĩa + ngữ cảnh; không cộng 64+76 hoặc loại trùng chỉ bằng chuỗi. `*` và `&` trong khai báo/biểu thức cần giữ những ý nghĩa khác nhau. Giữ tìm không dấu, `|`, `||` và dấu pipe trong GFM.
- Source §16 chỉ có tên/lịch sử bài thực hành; muốn web giao bài cần bổ sung đề, yêu cầu, input/output, rubric. Không coi một dòng tên project là bài tập hoàn chỉnh.

### Bảo toàn tiến độ và ôn tập

- Giữ key `cpp-dojo-state-v1`, các map progress/srs/exercises, ID quiz/card/exercise và lịch sử XP/streak. Không reset hoặc đổi ID hàng loạt.
- Thêm tiến độ khóa học có namespace riêng, ví dụ `courseProgress["cpp-02"]`; mục thư viện 3 đã đọc không tự chứng minh bài 02 và 03 mới đều hoàn thành.
- Tách trạng thái **theo tài liệu đã học**, **đã đọc trên web**, **kết quả quiz/thực hành**. Lần nhập nội dung không cấp điểm học tập.
- Giữ lịch SRS của thẻ đã có. Khi kiến thức được đính chính, ghi nội dung cập nhật/cần ôn mà không âm thầm xóa lịch sử; thẻ có mục tiêu mới hoàn toàn dùng ID mới.
- Mặc định ôn theo bài/phạm vi học đã chọn hoặc xác nhận; phần nâng cao/Unreal chủ động bật riêng. Áp cùng bộ lọc cho hàng đợi đầu phiên, “học thêm”, số lượng đến hạn ở Dashboard và các chỉ số liên quan.
- Đường dẫn `/lesson/:id`, `/reference?tab=syntax`, `/fundamentals?topic=...` còn truy cập được qua nội dung cũ hoặc alias rõ ràng. Không làm mất bookmark hay các resource ID integrated/questions/schedule.

## 7. Kết quả kiểm tra C++ đã làm trong lượt lập kế hoạch

Compiler: MSVC/Visual Studio 2022, `/std:c++17 /permissive- /EHsc /utf-8 /W4 /WX`.

Các mẫu kiểm tra chỉ nằm ngoài repository tại `C:/Users/REI/AppData/Local/Temp/cpp-01-13-audit-20261024`. Đoạn minh họa được bổ sung include/main/assert khi cần; không coi mọi fenced block của giáo trình là chương trình độc lập.

| Ca kiểm tra | Kết quả |
|---|---|
| Arena ba file kiểu int, lấy nguyên các block §06.5 | Build/run đạt; output `true`. |
| Ghép class Player bài 11 và tạo bằng constructor một tham số | Build/run đạt; damage cho HP 80 rồi 0. `Player(-10)` trả HP -10, xác nhận điều kiện đầu vào còn thiếu. |
| Virtual Animal/Dog §12.2, thêm include/main | Build/run đạt; output `Woof`. |
| Lifetime Animal/Dog §12.3 cùng unique_ptr | Build/run đạt; in `Dog destroyed` rồi `Animal destroyed`. |
| GameMath và Stat | Build/run đạt; kiểm tra int/float, trong/ngoài/đúng biên và min=max. Khoảng đảo của hàm tự viết trả 100; không phải một khoảng clamp hợp lệ. |
| Dòng make_unique ba đối số bài 10 kết hợp Player bài 11 | Build lỗi C2661: constructor Player không nhận ba đối số. |
| Literal `*nullptr` | Build lỗi C2100: illegal indirection. Không thực thi null dereference. |

Các ca này xác nhận những kết luận cụ thể; không phải chấm bài nộp của người học, không thay thế kiểm thử tất cả ví dụ sau biên tập và không chứng minh code có UB là an toàn.

## 8. Tiêu chí nghiệm thu cho lần triển khai sau

1. **Đủ nội dung:** manifest bao phủ từng phần nguồn 00–13 và resources 14–17 bằng bài, tài nguyên hoặc mục hoãn có lý do; buổi 06.5/12.1/12.2 không bị bỏ sót hoặc trùng số.
2. **Đúng kiến thức:** xử lý các vấn đề mục 4 trên mọi bề mặt liên quan. Không còn câu hỏi chấm output cố định cho chương trình UB.
3. **Đúng trình tự:** ví dụ cần kiến thức ngoài bài được dời hoặc đánh dấu liên kết tiên quyết; không buộc học Unreal để làm bài string/constructor cơ bản.
4. **Luyện tập đủ mục tiêu:** mỗi bài có ít nhất kiểm tra hiểu ý nghĩa, áp dụng/đọc code và bài tự viết/rubric tương ứng. Mỗi đáp án trỏ được về lý thuyết đã dạy.
5. **Code:** tất cả ví dụ được gắn nhãn chạy độc lập build theo C++17; test lỗi biên hữu ích. Ví dụ cố ý compile lỗi kiểm tra đúng loại lỗi; mẫu UB chỉ dùng nhận diện lỗi, không chạy làm oracle output.
6. **Tra cứu:** giữ các nhóm ý nghĩa hiện có, thêm memory/OOP/templates; mỗi mục có bài/anchor, cảnh báo điều kiện khi cần. Kiểm tra tìm không dấu, pipe, dấu `&`, nhóm và trạng thái không có kết quả.
7. **Kỹ thuật web:** cập nhật `check:handoff` hoặc thay bằng kiểm tra manifest/coverage; không giữ test hardcode bài09 chưa chấm hay số lượng cũ. Typecheck/build đạt, link và anchors hợp lệ.
8. **Dữ liệu người học:** dùng mẫu localStorage v1 có đủ read/quiz/practice/SRS/XP/streak/exercise link để kiểm tra chuyển đổi; reload và đóng/mở trang vẫn giữ dữ liệu. Không sinh hoàn thành/XP trùng khi xem cùng chủ đề qua hai lối.
9. **Giao diện:** kiểm tra desktop/mobile, code/table ngang, tìm kiếm, trước/sau, Tiếp tục, filter ôn tập và các bookmark cũ. UI thể hiện rõ phần tham khảo và phần đã học.
10. **CI và phát hành:** workflow hiện chỉ chạy build; lần triển khai cần thêm kiểm tra nội dung và job C++ phù hợp. Sau khi được yêu cầu đưa lên web mới push/deploy, rồi đối chiếu phiên bản live.

Thứ tự ưu tiên: **sửa lỗi và chuẩn hóa nguồn → tổ chức lại lộ trình → đồng bộ luyện tập/tra cứu → bảo toàn tiến độ → kiểm định → triển khai khi được yêu cầu**. Chưa bắt đầu bất kỳ bước sửa web nào trong kế hoạch này.
